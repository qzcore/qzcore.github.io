# Thư mục 01: Ngân hàng đề thô (Chưa thẩm định)

Thư mục này chứa các tệp câu hỏi thô dạng JSON (mỗi tệp tương ứng với một chương/chủ đề):

- **Nguồn tạo:** Do trợ lý AI hỗ trợ sinh ra hoặc do giảng viên nhập thô.
- **Quy chuẩn đặt tên tệp:** `C<Số_thứ_tự_chương>_<Tên_chương_viết_liền_không_dấu>.json` (ví dụ: `C01_TongQuan.json`, `C05_UocLuongThamSo.json`).
- **Quy trình xử lý:** Mở ứng dụng **`06_duyet_va_tao_de/Duyet_va_tao_de.html`** ➔ Tab **"🔍 Thẩm định & duyệt đề thô"** để tự động kiểm tra lỗi kỹ thuật (V01 – V11), chỉnh sửa và phê duyệt sang thư mục `02_ngan_hang_de/`.

