# Thư mục 00: Dữ liệu ra đề & Tài liệu học phần (Single Source of Truth)

> **Tác giả phát triển:** T.M.Tường & Trợ lý AI Antigravity  
> **Vai trò:** Nguồn chân lý duy nhất lưu trữ toàn bộ dữ liệu kiến thức nền tảng, công thức và chuẩn đầu ra để trợ lý AI đọc và sinh câu hỏi trắc nghiệm chuẩn mực.

---

## Các tài liệu lưu trữ trong thư mục:

1. **Tài liệu chuyên đề Quarto chuẩn hóa (`tai_lieu_<MÃ_CHƯƠNG>_<TÊN_CHƯƠNG>.qmd`):**
   - Do Trợ lý AI (skill `curriculum-topic-creator`) tự động khảo sát chương trình và xuất bản theo Cây 2 cấp độ (Chương ➔ Chuyên đề con).
   - Chứa toàn bộ YCCĐ, tóm tắt lý thuyết, công thức KaTeX/LaTeX, phương trình hóa học, các dạng bài tập điển hình và các bẫy tư duy kinh điển.
   - Trợ lý AI tạo đề (`exam-creator`) sẽ đọc trực tiếp tệp này làm căn cứ sinh câu hỏi trắc nghiệm có phân cấp `subTopic`.
   - Giảng viên có thể biên dịch sang PDF bằng Quarto (`quarto render ... --to pdf`) để in ấn phát cho sinh viên.
2. **Đề cương chi tiết học phần:** Các tệp `.docx`, `.pdf`, `.md` mô tả chuẩn đầu ra (CLOs) và ma trận đề thi.
3. **Tài liệu học tập & Giáo trình:** Bài giảng, slide trình chiếu, tài liệu tham khảo chính.
4. **Đề thi mẫu hoặc đề thi các kỳ trước:** Dùng làm dữ liệu đối sánh chuẩn mực.


