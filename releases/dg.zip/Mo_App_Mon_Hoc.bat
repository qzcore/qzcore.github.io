@echo off
chcp 65001 >nul
title QZCore - Khoi dong Ung dung Khao thi (App Mode)

set "CURR_DIR=%~dp0"
set "HTML_PATH=%CURR_DIR%06_duyet_va_tao_de\Duyet_va_tao_de.html"
if not exist "%HTML_PATH%" (
    set "HTML_PATH=%CURR_DIR%Duyet_va_tao_de.html"
)

if not exist "%HTML_PATH%" (
    echo [LOI] Khong tim thay tep Duyet_va_tao_de.html!
    pause
    exit /b 1
)

:: Chuyen dau gach cheo nguoc thanh xuoi cho duong dan file:///
set "URL_PATH=%HTML_PATH:\=/%"
if exist "%CURR_DIR%.app_profile" rd /s /q "%CURR_DIR%.app_profile" 2>nul
set "APP_FLAGS=--app=file:///%URL_PATH%"

echo [QZCore] Dang khoi dong ung dung o che do Cua so doc lap (PWA App Mode)...

:: 1. Uu tien Microsoft Edge (Co san 100% tren Windows 10/11)
start "" msedge.exe %APP_FLAGS% 2>nul
if %errorlevel% equ 0 exit

:: 2. Uu tien Google Chrome
start "" chrome.exe %APP_FLAGS% 2>nul
if %errorlevel% equ 0 exit

:: 3. Uu tien Brave
start "" brave.exe %APP_FLAGS% 2>nul
if %errorlevel% equ 0 exit

:: 4. Neu khong tim thay trong PATH, quet cac duong dan cai dat mac dinh
if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" %APP_FLAGS%
    exit
)
if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" %APP_FLAGS%
    exit
)
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles%\Google\Chrome\Application\chrome.exe" %APP_FLAGS%
    exit
)
if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" %APP_FLAGS%
    exit
)

:: 5. Mac dinh mo bang trinh duyet he thong
start "" "%HTML_PATH%"
exit
