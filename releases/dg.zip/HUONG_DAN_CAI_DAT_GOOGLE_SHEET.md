# Hướng dẫn cài đặt Google Sheets & Triển khai phòng thi online

Tài liệu này hướng dẫn Giảng viên thiết lập bảng tính quản trị Google Sheets trên Google Drive môn học để tự động chấm điểm, quản lý gian lận và cấp link thi trực tuyến cho sinh viên.

---

## 1. Mục đích của Google Sheet
Google Sheet đóng vai trò là "Bộ não trung tâm" trên Google Drive:
- Lưu bảng điểm tự động vào sheet `KetQua`.
- Lưu chi tiết từng phương án thí sinh chọn tại `ChiTietBaiLam`.
- Ghi nhận nhật ký chống gian lận (chuyển tab, mất tiêu điểm) tại `NhatKyViPham`.
- Điều phối phòng thi và cấp đường link Web App làm bài trực tuyến.

---

## 2. Quy trình Cài đặt Siêu tốc qua Bảng tính Mẫu (Khuyên dùng — Chỉ 30 giây!)

Nhờ kiến trúc bản mẫu 1-chạm của v5.0, Thầy/Cô **hoàn toàn không cần viết mã hay cấu hình thư viện thủ công**. Toàn bộ quy trình rút gọn chỉ còn 3 bước:

### Bước 1: Nhận Bảng tính Quản trị Mẫu (Tạo bản sao 1-Chạm)
1. Mở tệp **`Duyet_va_tao_de.html`** trên máy tính, chuyển sang tab **"🌐 Quản trị Cloud"**.
2. Ngay ở đầu khung kết nối, bấm nút xanh: **`[ 📋 Nhận Bảng tính Mẫu (Tạo bản sao) ↗ ]`**.
3. Tab Google mở ra trên trình duyệt (đã đăng nhập tài khoản Google), bấm nút **"Tạo bản sao"** (Make a copy).
4. Bảng tính mới lập tức được tạo ngay trên Google Drive của Thầy/Cô với đầy đủ mã cầu nối và Thư viện `TracNghiemCore` phiên bản mới nhất!

### Bước 2: Triển khai Web App lấy đường link
1. Trên menu của Bảng tính Google Sheet vừa tạo, chọn: **Tiện ích mở rộng (Extensions) ➔ Apps Script**.
2. Ở góc trên bên phải màn hình Apps Script, bấm nút xanh **Triển khai (Deploy)** ➔ Chọn **Lần triển khai mới (New deployment)**.
3. Bấm biểu tượng bánh răng ⚙️ ➔ Chọn loại **Ứng dụng web (Web app)**:
   - **Mô tả:** Triển khai cổng thi trắc nghiệm v5.0.
   - **Thực thi dưới quyền (Execute as):** Chọn `Tôi (Me)`.
   - **Người có quyền truy cập (Who has access):** Chọn `Bất kỳ ai (Anyone)`.
4. Bấm nút **Triển khai (Deploy)**:
   - Nếu Google yêu cầu cấp quyền, bấm *Xem lại quyền ➔ Chọn tài khoản ➔ Nâng cao (Advanced) ➔ Đi tới... (không an toàn) ➔ Cho phép*.
   - Bấm **Sao chép URL ứng dụng web** (đường link có kết thúc bằng `/exec`).

### Bước 3: Ghép đôi 1-Chạm về ứng dụng máy tính
1. Quay lại ứng dụng **`Duyet_va_tao_de.html`** tại tab **"🌐 Quản trị Cloud"**.
2. Dán đường link URL vừa sao chép vào ô **Google Apps Script Web App URL**.
3. Ô *Mã bí mật Quản trị*: **Để trống** (hệ thống sẽ tự sinh và ghép đôi tự động).
4. Bấm nút **"🔄 Kết nối"**:
   - Hệ thống tự động kiểm tra, khởi tạo 5 sheet chuẩn và 7 thư mục môn học trên Google Drive.
   - Huy hiệu chuyển sang **"🟢 Đã kết nối"**, đồng thời hiển thị nút **"📂 Mở thư mục trên Google Drive ↗"** để truy cập Drive tức thì!

---

## 2B. Quy trình Thủ công (Dành cho Giảng viên muốn tự tạo từ Sheet trắng)

Nếu Thầy/Cô muốn tự cấu hình trên một file Google Sheet có sẵn thay vì dùng bản mẫu:
1. **Tạo Sheet mới:** Trên Google Drive, bấm *+ Mới ➔ Google Trang tính*.
2. **Dán mã cầu nối:** Vào *Tiện ích mở rộng ➔ Apps Script*. Mở tệp `templates/Ma_Nguon_Google_Sheet_ThinClientWrapper.txt`, sao chép toàn bộ nội dung và dán vào file `code.gs`. Bấm `Ctrl + S` lưu lại.
3. **Gắn Thư viện:** Ở cột trái Apps Script, bấm `+` tại mục *Thư viện (Libraries)*. Dán Script ID:
   ```text
   1ghooDuJ6Mbs5ai7B1XDivHX0t8u65lrRrQ-vNHhmzfWIubjoyEAkgKi-
   ```
   Bấm *Tra cứu* ➔ Chọn Version cao nhất (Version 38) ➔ Đặt Định danh là `TracNghiemCore` ➔ Bấm *Thêm*.
4. **Triển khai:** Thực hiện các bước Triển khai Web App tương tự như Bước 2 ở trên để lấy URL `/exec`.

> [!TIP]
> **Lưu ý kiểm tra thư mục & Cấp quyền Drive:**
> 1. **Vị trí thư mục:** Các thư mục `00_` đến `06_` được tạo **nằm cạnh file Google Sheet** trong thư mục môn học trên Google Drive, không nằm ngoài màn hình "Drive của tôi".
> 2. **Cấp quyền Drive lần đầu:** Khi bấm Khởi tạo, nếu Google yêu cầu xem xét quyền, hãy bấm *Nâng cao (Advanced) ➔ Đi tới dự án ➔ Cho phép*.
> 3. **Xem bắt lỗi nhanh:** Nếu gặp bất kỳ trục trặc nào, bấm nút **`📜 Nhật ký`** trên thanh Top Bar để xem ngay lỗi hoặc bấm nút sao chép gửi Zalo cho Tác giả để được hỗ trợ tức thì!

---

## 3. Đường link gửi cho Sinh viên

Thầy/cô chỉ cần gửi duy nhất đường link Web App chính (hoặc mã QR tại tab Quản trị Cloud):
👉 **`https://script.google.com/macros/s/.../exec`**

Khi mở link này, sinh viên sẽ thấy giao diện **Cổng Khảo thí & Luyện tập Trắc nghiệm** với 3 chế độ:
- **📝 Vào thi chính thức (Exam Mode)**
- **💡 Vào luyện tập tự do (Practice Mode)**
- **📚 Làm bài tập tự học có chấm hạn (Assignment Mode)**

---

## 4. Cách tổ chức thi mỗi đợt (100% trên máy tính cá nhân — 1-chạm)
1. Mở `06_duyet_va_tao_de/Duyet_va_tao_de.html` trên máy tính, tạo đề thi tại Tab 2.
2. Bấm **"Lưu đề thi"** ➔ Bấm **"🚀 Đẩy lên Cloud & Mở phòng thi ngay (1-chạm)"**:
   - Đề thi tự động bay lên Google Drive.
   - Phòng thi tự động mở; màn hình hiển thị mã QR Code cho sinh viên quét vào thi ngay lập tức.
3. Khi hết giờ, bấm **"🔴 Đóng phòng thi"** và bấm **"📥 Tải kết quả thi"** để xem và xuất bảng điểm trực tiếp về máy tính. Thầy/Cô hoàn toàn không cần thao tác thủ công kéo thả tệp hay mở Google Sheet!
5. Chọn menu **⚙️ HỆ THỐNG THI TRẮC NGHIỆM ➔ 🌐 4. Lấy liên kết phòng thi (Web App)** ➔ Sao chép link gửi cho sinh viên làm bài!

---

## 5. Quy tắc vàng khi Triển khai & Cập nhật mã nguồn (Giữ link cố định vĩnh viễn)

> [!IMPORTANT]
> **Tại sao không nên bấm "Lần triển khai mới" (New deployment) nhiều lần?**  
> Mỗi lần bấm "Lần triển khai mới", Google sẽ tạo ra một **Deployment ID mới** (ví dụ `.../s/AKfycb_MỚI/exec`). Việc này khiến:
> 1. Đường link cũ gửi cho sinh viên bị chết hoặc mất hiệu lực.
> 2. `ScriptApp.getService().getUrl()` trong Google Sheet không tự đồng bộ được ID mới, dẫn đến lỗi Google Drive: *"Sorry, unable to open the file at this time"*.

### Cách cập nhật chuẩn của Google (Link cố định 100%):
1. Mở Apps Script ➔ Bấm **Triển khai (Deploy)** ➔ Chọn **Quản lý bản triển khai (Manage deployments)**.
2. Bấm vào biểu tượng **Cây bút chì (Chỉnh sửa / Edit)** ở góc trên bên phải.
3. Ở dòng **Phiên bản (Version)**: Bấm chọn **Phiên bản mới (New version)**.
4. Bấm **Triển khai (Deploy)**.
👉 **Kết quả:** Mã nguồn mới được áp dụng ngay lập tức, trong khi **URL Web App giữ nguyên vĩnh viễn**, sinh viên và giảng viên không bao giờ phải đổi link!

---

## 6. Xử lý sự cố thường gặp (Troubleshooting)

### ⚠️ Lỗi 1: Hộp thoại yêu cầu nhập link Web App thủ công
- **Nguyên nhân:** Google Sheet chưa lưu link deploy hợp lệ trong ô `B2` của trang tính `CauHinh` hoặc bộ nhớ cache.
- **Cách xử lý đơn giản nhất (Làm 1 lần duy nhất):**
  1. Mở trang tính `CauHinh` trên Google Sheet.
  2. Tại dòng có khóa `webAppUrl`, dán đường link Web App của thầy/cô (dạng `https://script.google.com/macros/s/.../exec`) vào ô giá trị (cột B).
  3. Từ nay về sau, khi bấm menu **🌐 4. Lấy liên kết phòng thi**, hệ thống sẽ lập tức hiển thị 2 thẻ link kèm nút sao chép mà không bao giờ hỏi lại nữa!

### ⚠️ Lỗi 2: Tự động lấy bản deploy mới nhất qua Apps Script API (Tùy chọn nâng cao)
Nếu thầy/cô muốn hệ thống tự động quét danh sách các lần deploy và lấy bản mới nhất mà không cần dán vào sheet `CauHinh`:
1. Trong Apps Script, vào **Cài đặt dự án (Project Settings)** (biểu tượng bánh răng ở thanh công cụ bên trái).
2. Tích chọn ô: **Hiển thị tệp kê khai "appsscript.json" trong trình chỉnh sửa** (*Show "appsscript.json" manifest file in editor*).
3. Quay lại mục **Trình chỉnh sửa (Editor)** ➔ Bấm vào tệp **`appsscript.json`**.
4. Sao chép nội dung từ tệp mẫu **`templates/appsscript.json`** dán vào thay thế toàn bộ ➔ Bấm 💾 **Lưu dự án**.
5. Triển khai lại phiên bản mới. Giờ đây hệ thống sẽ tự động gọi Google Apps Script API để nhận diện bản deploy mới nhất!

### ⚠️ Lỗi 3: "Sorry, unable to open the file at this time. Please check the address and try again"
Nếu khi bấm vào link Web App mà Google Drive báo lỗi này, nguyên nhân do:
1. **Chưa cấp quyền "Bất kỳ ai" (Anyone):**
   - Vào Apps Script ➔ **Triển khai** ➔ **Quản lý bản triển khai** ➔ Bấm bút chì ✏️.
   - Đảm bảo mục **Người có quyền truy cập (Who has access)** là **`Bất kỳ ai (Anyone)`**.
   - Chọn **Phiên bản mới** ➔ Bấm **Triển khai**.
2. **Xung đột tài khoản trường do tiền tố `/a/ufm.edu.vn/`:**
   - Phiên bản Wrapper v3.5 đã tích hợp bộ lọc tự động cắt bỏ cụm `/a/ufm.edu.vn/`, đảm bảo link luôn ở định dạng toàn cầu `https://script.google.com/macros/s/.../exec`.


