# Hướng dẫn sử dụng công cụ duyệt đề và tạo đề thi offline

Công cụ **`Duyet_va_tao_de.html`** là ứng dụng độc lập 100% chạy cục bộ trên trình duyệt máy tính (Google Chrome hoặc Microsoft Edge), không cần cài đặt phần mềm phụ trợ hay chạy server dòng lệnh. Ứng dụng tích hợp 2 phân hệ chuyên trách cho giảng viên:

1. **Phân hệ 1 (Tab 🔍 Thẩm định & duyệt đề thô):** Kiểm tra 11 tiêu chuẩn kỹ thuật (V01 – V11), kiểm soát trùng lặp 4 tầng, chỉnh sửa trực quan (Live Preview KaTeX) và phê duyệt chuyển câu hỏi từ `01_ngan_hang_de_tho/` sang `02_ngan_hang_de/`.
2. **Phân hệ 2 (Tab 📝 Tạo đề thi chính thức):** Tự động bốc đề thi từ ngân hàng đã duyệt `02_ngan_hang_de/` theo ma trận 60/30/10, thuật toán Largest Remainder, hỗ trợ đơn đề hoặc Gói đa mã đề (Đề 101, 102, 103, 104...), đổi câu hỏi linh hoạt (Reroll) và lưu trực tiếp vào `03_de_thi/` trên máy tính.

---

## 1. Cách khởi động ứng dụng

1. Bấm đúp chuột vào tệp **`Duyet_va_tao_de.html`** để mở bằng Google Chrome hoặc Microsoft Edge.
2. **Đăng ký Giảng viên (Lần đầu):** Điền thông tin Họ tên, Đơn vị, Môn học và Email trên hộp thoại cam kết bảo vệ dữ liệu. Sau này có thể cập nhật qua nút **`👤 Giảng viên & Môn học`** trên thanh Top Bar.
3. Bấm nút **"📁 Chọn thư mục môn học"** ở góc trên bên phải ➔ Chọn thư mục môn học vừa giải nén trên máy tính (ví dụ: `PTDLKD`, `Toan_kinh_te`...).
4. Trình duyệt sẽ yêu cầu cấp quyền đọc/ghi thư mục ➔ Bấm **"Xem tệp"** (View files) / **"Lưu thay đổi"** (Save changes) để kết nối.
5. **Hỗ trợ kỹ thuật 24/7:** Nếu gặp bất kỳ sự cố nào, bấm nút **`📜 Nhật ký`** trên Top Bar và bấm **"📋 Sao chép nhật ký gửi Zalo cho Tác giả"** để được giải đáp ngay.

---

## 2. Quy trình làm việc 2 bước

```
[01_ngan_hang_de_tho] ──(Tab 1: Thẩm định & Duyệt)──> [02_ngan_hang_de] ──(Tab 2: Tạo đề thi)──> [03_de_thi]
                                                                                                    │
                                                                       ┌────────────────────────────┴───────────────────────────┐
                                                                       ▼                                                        ▼
                                                        Kéo thả lên Google Drive                                  Biên dịch Quarto/PDF
                                                    (Khảo thí trực tuyến WebClient)                           (Đề in ấn thi trên giấy)
```

### Bước 1: Thẩm định & duyệt câu hỏi (Tab 🔍)

- Chọn chương học ở danh mục bên trái.
- Kiểm tra nội dung câu hỏi, công thức KaTeX và bảng số liệu.
- Bấm **"Phê duyệt"** (hoặc **"Duyệt tất cả câu hợp lệ"**) để đưa câu hỏi vào ngân hàng chính thức `02_ngan_hang_de/`.
- Nếu cần chỉnh sửa nội dung, bấm **"Chỉnh sửa"** để mở khung soạn thảo Live Preview (hỗ trợ phím tắt `Ctrl + Enter` để lưu nhanh).

### Bước 2: Tạo đề thi chính thức (Tab 📝)

- Chuyển sang tab **"📝 Tạo đề thi chính thức"**.
- Thiết lập thông số:
  - **Tên đề thi:** Ví dụ *Đề thi kết thúc học phần - Học kỳ 1*.
  - **Mã đề cơ sở:** Tự động sinh `DT_YYYYMMDD_HHMM` (hoặc bấm nút "Sinh" để lấy mã mới).
  - **Số lượng mã đề:** 1 mã đề (đơn nhất), Gói 2 mã đề (Đề 101, 102), Gói 4 mã đề (Đề 101, 102, 103, 104), Gói 6 mã đề, Gói 8 mã đề.
  - **Thời gian làm bài:** Mặc định 45 giây/câu (tương đương 30 phút cho 40 câu).
  - **Quyền xem đáp án:** 🔒 Không hiện chi tiết (Chuẩn thi thật - chống lộ đề) hoặc 🔓 Hiện chi tiết (Chuẩn thi thử/ôn tập).
- Chọn chế độ phân bổ:
  - **Chế độ 1 (Tùy chọn):** Nhập trực tiếp số câu cần lấy cho từng chương học đã duyệt.
  - **Chế độ 2 (Tự động):** Nhập tổng số câu (ví dụ: 40 câu), hệ thống tự động phân bổ đều theo số câu khả dụng giữa các chương bằng thuật toán Largest Remainder và ma trận 60/30/10.
- Bấm **"⚡ Sinh đề thi & Xem trước"**:
  - Xem trước từng mã đề thi (Đề 101, Đề 102...).
  - Kiểm tra ma trận thực tế: Tỷ lệ % Nhận biết, Vận dụng, Vận dụng cao.
  - Nếu muốn thay đổi một câu hỏi bất kỳ, bấm **"🔄 Đổi câu khác cùng mức độ"** để hệ thống tự động bốc câu dự phòng khác trong chương đó.
- Bấm **"💾 Lưu vào 03_de_thi/"**:
  - Tệp đề thi snapshot JSON sẽ được ghi trực tiếp vào thư mục `03_de_thi/<Mã_đề>.json` trên máy tính.

---

## 3. Cách kích hoạt đề thi trực tuyến (Google Drive)

Sau khi tạo đề thi thành công ở Bước 2:

1. Mở thư mục `03_de_thi/` trên Google Drive môn học của thầy/cô.
2. Kéo thả tệp JSON vừa tạo (ví dụ: `DT_20261107_1630.json`) từ máy tính vào thư mục Drive đó.
3. Mở bảng tính Google Sheets của môn học ➔ Chọn menu **Quản trị đề thi ➔ Kích hoạt đề thi** ➔ Chọn tên tệp vừa tải lên.
4. Gửi liên kết Cổng làm bài cho sinh viên: `<Web_App_URL>/exec`. Sinh viên mở link sẽ tự chọn thi chính thức hoặc luyện tập tự do!

---

## 4. Các phím tắt tiện ích

- `Esc`: Đóng nhanh hộp thoại chỉnh sửa hoặc bảng thông báo.
- `Ctrl + Enter` (hoặc `Cmd + Enter` trên macOS): Lưu nhanh câu hỏi đang chỉnh sửa trên modal.
