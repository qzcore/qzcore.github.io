# Bộ prompt AI chuẩn hóa khảo sát chuyên đề & tạo câu hỏi trắc nghiệm (v5.0)

> **Tác giả phát triển:** T.M.Tường & Trợ lý AI Antigravity  
> **Quy trình chuẩn mực 2 bước:**
> - **Bước 1 (Chuẩn bị dữ liệu):** Dùng **Prompt 0** để khảo sát chương trình, thiết lập Cây chuyên đề 2 cấp độ và xuất bản tài liệu Quarto (`.qmd`) vào `00_du_lieu_ra_de/`.
> - **Bước 2 (Biên soạn câu hỏi):** Dùng **Prompt 1, 2, 3** để đọc tài liệu `.qmd` và sinh câu hỏi trắc nghiệm có phân cấp `subTopic` vào `01_ngan_hang_de_tho/`.

---

## Quy chuẩn bắt buộc của hệ thống (System Requirements)

Mọi câu hỏi sinh ra đều phải tuân thủ nghiêm ngặt:
1. **Đáp án đúng (`correct`):** Phải là **chỉ số số nguyên 0-based** (`0, 1, 2, 3`) tương ứng với vị trí trong mảng `options` (`0` = phương án đầu tiên đúng, `1` = phương án thứ hai đúng...).
2. **Mảng lời giải song song (`explanations[]`):** Phải có đúng số lượng phần tử bằng số phương án trong `options` (thường là 4).
   - **Tuyệt đối KHÔNG dùng ký hiệu chữ cái A, B, C, D trong lời giải** (vì hệ thống tự động xáo trộn vị trí phương án khi sinh viên luyện tập).
   - Phương án đúng: Bắt đầu bằng `✅` kèm phân tích bản chất, cơ chế toán học/kỹ thuật.
   - Phương án sai: Bắt đầu bằng `❌` kèm phân tích chính xác bẫy sai lầm khiến người học hay chọn nhầm.
   - Mỗi phần tử ngắn gọn từ 1–3 câu.
3. **Công thức toán học & hóa học:** Viết theo chuẩn KaTeX trong cặp dấu `$ ... $` cho công thức nội dòng hoặc `$$ ... $$` cho công thức khối. Đối với công thức / phương trình hóa học, sử dụng cú pháp `mhchem`: `$\ce{Cu}$`, `$\ce{H2SO4}$`, `$\ce{SO2}$`, `$\ce{2H2 + O2 -> 2H2O}$`.
4. **Quy chuẩn số thập phân tiếng Việt:** Dấu phẩy số thập phân viết liền không chèn khoảng trắng sau dấu phẩy (viết đúng: `12,8 gam`, `2,479 lít`; tuyệt đối KHÔNG viết cách: `12, 8`, `2, 479`).
5. **Đa phương tiện & Định dạng chuyên ngành:**
   - **Môn Tin học / Lập trình:** Đặt mã nguồn trong khối ` ```python ... ``` ` hoặc ` ```cpp ... ``` `.
   - **Môn Vật lý / Sinh học / Địa lý / Âm nhạc:** Chèn hình ảnh hoặc khuông nhạc bằng `![Chú thích](URL_HINH_ANH)`.
   - **Bài thi nghe (Ngoại ngữ / Âm nhạc thẩm âm):** Chèn tệp âm thanh bằng `[audio: URL_MP3]`.
   - **Ký hiệu Âm nhạc:** Hỗ trợ trực tiếp ký hiệu Unicode: `♩`, `♪`, `♫`, `♭`, `♯`, `♮`.
6. **Độ dài phương án:** Bốn phương án phải có độ dài và văn phong tương đương, tránh việc đáp án đúng luôn là câu dài nhất.
7. **Cơ cấu ma trận:** Tuân thủ tỷ lệ 60% Nhận biết & Thông hiểu (`Nhan_biet_Thong_hieu`), 30% Vận dụng (`Van_dung`), 10% Vận dụng cao (`Van_dung_cao`).
8. **Độc lập dữ liệu tuyệt đối (Standalone Question):** Mỗi câu hỏi phải chứa đầy đủ 100% ngữ cảnh, bảng số liệu hoặc tham số để thí sinh giải quyết độc lập. Tuyệt đối KHÔNG tạo câu hỏi phụ thuộc bắc cầu (*"Dựa vào số liệu ở câu trước...", "Với bảng ở Câu 1, hãy tính..."*) vì hệ thống sẽ xáo trộn ngẫu nhiên thứ tự câu hỏi khi thi.
9. **Phân cấp Chủ đề con (`subTopic` - Micro-learning):** Mỗi câu hỏi BẮT BUỘC có trường `"subTopic": "X.Y Tên chủ đề con"` để phân loại bài học tuần, phục vụ tự luyện vi mô và cho phép giảng viên lọc câu hỏi khi giao bài tập có định hạn. Mã `id` câu hỏi chia theo khối trăm tương ứng (`_101`..`_199` cho CĐ 1, `_201`..`_299` cho CĐ 2...).

---

## Prompt 0: Khảo sát chương trình, thiết lập Cây chuyên đề 2 cấp độ và xuất bản Quarto (.qmd)

```markdown
Bạn là Kiến trúc sư Chương trình & Khảo thí học thuật phụ trách môn học: [TÊN_MÔN_HỌC, ví dụ: Hóa học 11 GDPT 2018 / Phân tích dữ liệu kinh doanh].
Hãy khảo sát chương trình học chính thức và xây dựng Cây chuyên đề 2 cấp độ cho: [TÊN_CHƯƠNG, ví dụ: Chương 2: Nitrogen và Sulfur / Chương 2: Tóm tắt và phân tổ dữ liệu].

Yêu cầu thực hiện:
1. Thiết lập Cây chuyên đề 2 cấp độ:
   - Cấp 1: Mã chương [MÃ_CHƯƠNG, ví dụ: C02] và Tên chương lớn.
   - Cấp 2: Chia thành 3 đến 5 Chuyên đề con bài học tuần (Mã: 2.1, 2.2, 2.3...), mỗi chuyên đề xác định rõ:
     + Tên chuyên đề con bài học.
     + Phạm vi kiến thức trọng tâm.
     + Yêu cầu cần đạt (YCCĐ): Nhận biết, hiểu, vận dụng và tính toán được gì.
2. Trích xuất kiến thức cốt lõi, công thức tính toán / phương trình chuẩn xác (dùng KaTeX $...$, $$...$$ hoặc mhchem).
3. Đúc kết danh mục các dạng bài tập điển hình và các bẫy tư duy kinh điển học sinh hay mắc phải.
4. Trình bày đầu ra hoàn chỉnh dưới dạng tệp tài liệu Quarto (.qmd) sẵn sàng lưu vào:
   00_du_lieu_ra_de/tai_lieu_[MÃ_CHƯƠNG]_[TÊN_CHƯƠNG].qmd
```

---

## Prompt 1: Tạo câu hỏi lý thuyết và tính toán cơ bản (Nhận biết & Thông hiểu)

```markdown
Bạn là chuyên gia khảo thí đại học phụ trách môn học: [TÊN_MÔN_HỌC, ví dụ: Toán kinh tế / Phân tích dữ liệu kinh doanh].
Hãy biên soạn giúp tôi [SỐ_LƯỢNG, ví dụ: 5] câu hỏi trắc nghiệm 4 lựa chọn cho chủ đề: [TÊN_CHỦ_ĐỀ, ví dụ: Chương 1 - Ma trận và hệ phương trình tuyến tính].

Yêu cầu kỹ thuật bắt buộc:
1. Định dạng đầu ra: Trả về duy nhất một khối mã JSON hợp lệ (không kèm lời dẫn) theo cấu trúc mảng câu hỏi:

[
  {
    "id": "[MÃ_MÔN]_[MÃ_CHỦ_ĐỀ]_[SỐ_TT, ví dụ: TKT_C01_101]",
    "subject": "[MÃ_MÔN, ví dụ: Toan_Kinh_Te]",
    "subTopic": "[TÊN_CHỦ_ĐỀ_CON, ví dụ: 1.1 Khái niệm và các phép toán ma trận]",
    "type": "mcq_single",
    "level": "Nhan_biet_Thong_hieu",
    "score": 0.5,
    "question": "Nội dung câu hỏi rõ ràng, sư phạm. Công thức toán đặt trong $...$ hoặc $$...$$",
    "options": [
      { "id": "A", "text": "Nội dung phương án 1" },
      { "id": "B", "text": "Nội dung phương án 2" },
      { "id": "C", "text": "Nội dung phương án 3" },
      { "id": "D", "text": "Nội dung phương án 4" }
    ],
    "correct": 0,
    "explanations": [
      "✅ Đúng. Nêu rõ nguyên lý, công thức hoặc bản chất cơ chế.",
      "❌ Sai. Nêu rõ bẫy sai lầm hoặc lỗi tính toán khiến sinh viên hay chọn phương án này.",
      "❌ Sai. Nêu rõ lỗi nhầm lẫn khái niệm tương tự.",
      "❌ Sai. Nêu rõ lỗi làm tròn hoặc nhầm công thức."
    ],
    "tags": ["khai_niem_1", "cong_thuc_2"]
  }
]

2. Phân bố vị trí đáp án đúng: Hãy xáo trộn ngẫu nhiên vị trí đáp án đúng, đặt `correct` lần lượt ở các vị trí 0, 1, 2, 3 sao cho đồng đều (không để tất cả đáp án đúng đều nằm ở vị trí đầu tiên).
3. Đảm bảo toàn bộ công thức KaTeX/mhchem viết chuẩn xác, dấu $ được đóng mở cân bằng; số thập phân tiếng Việt viết liền (ví dụ: 12,8 không viết cách 12, 8).
```

---

## Prompt 2: Tạo câu hỏi tình huống thực tế và vận dụng cao (Vận dụng & Vận dụng cao)

```markdown
Bạn là giảng viên đại học phụ trách môn: [TÊN_MÔN_HỌC].
Hãy tạo [SỐ_LƯỢNG, ví dụ: 3] câu hỏi trắc nghiệm mức độ [Van_dung / Van_dung_cao] gắn liền với bài toán kinh tế / thực tế cho chủ đề: [TÊN_CHỦ_ĐỀ].

Yêu cầu:
1. Đề bài có số liệu cụ thể, tình huống thực tế (doanh thu, chi phí, lãi suất, kiểm định dữ liệu mẫu...).
2. Các phương án nhiễu (distractors) phải được tính toán từ các lỗi tư duy điển hình:
   - Quên căn bậc hai của n trong mẫu số.
   - Nhầm lẫn giữa kiểm định 1 phía và 2 phía.
   - Quên chiết khấu dòng tiền về hiện giá.
   - Lỗi chia nhầm n thay vì n - 1 cho phương sai mẫu hiệu chỉnh.
3. Trả về đúng định dạng JSON:
   - `subTopic`: Tên mục con bài học (ví dụ: `"1.2 Bài toán vận dụng"`).
   - `correct`: Số nguyên 0, 1, 2 hoặc 3.
   - `explanations`: Đúng 4 phần tử song song, bắt đầu bằng `✅` (phương án đúng) và `❌` (phương án sai), không dùng chữ cái A/B/C/D.
```

---

## Prompt 3: Chuyển đổi đề thi có sẵn (Word/PDF/Text) sang JSON hệ thống

```markdown
Bạn là trợ lý chuyển đổi dữ liệu khảo thí. Dưới đây là nội dung các câu hỏi trắc nghiệm thô từ tài liệu của tôi:

[DÁN NỘI DUNG CÂU HỎI THÔ VÀO ĐÂY]

Hãy chuyển đổi toàn bộ danh sách câu hỏi trên sang định dạng JSON chuẩn của hệ sinh thái khảo thí:
1. Chuyển đổi đáp án đúng sang số nguyên 0-based: A -> 0, B -> 1, C -> 2, D -> 3.
2. Viết lại lời giải thành mảng `explanations[]` gồm 4 phần tử tương ứng với 4 phương án:
   - Phần tử đúng: Bắt đầu `✅` + lý do đúng.
   - Ba phần tử sai: Bắt đầu `❌` + lý giải vì sao phương án đó sai / bẫy sai lầm.
   - Tuyệt đối không dùng các từ "Chọn A", "Chọn B" trong lời giải.
3. Chuẩn hóa công thức toán/hóa học sang cú pháp KaTeX/mhchem `$ ... $` (ví dụ: `$\ce{Cu}$`, `$\ce{H2SO4}$`); số thập phân viết liền không cách (ví dụ: `12,8`).
4. Gán mã câu `id`, `subject`, `subTopic` (tên mục con bài học), `level` (`Nhan_biet_Thong_hieu`, `Van_dung`, hoặc `Van_dung_cao`).
5. Xuất ra khối mã JSON hợp lệ 100%.
```

