# Thư mục Templates: Biểu mẫu & Tài nguyên biên soạn đề thi

Thư mục này chứa các biểu mẫu chuẩn hóa phục vụ công tác xây dựng ngân hàng câu hỏi trắc nghiệm và đề thi:

1. **`prompt-ai-tao-de.md`:** Tập hợp các câu lệnh (prompts) chuẩn hóa để giảng viên sử dụng trực tiếp với AI (Antigravity, Gemini, ChatGPT, Claude) để tạo câu hỏi trắc nghiệm đúng 100% chuẩn kỹ thuật.
2. **`mau-soan-de.md`:** Biểu mẫu hướng dẫn soạn thảo câu hỏi bằng Markdown (dành cho giảng viên muốn gõ tay hoặc xuất thô từ Word).
3. **`topic_template.json`:** Cấu trúc JSON mẫu của một chương/chủ đề trong ngân hàng đề thi (`01_ngan_hang_de_tho/` và `02_ngan_hang_de/`).
4. **`exam_template.json`:** Cấu trúc JSON mẫu của một đề thi snapshot chính thức (`03_de_thi/`).
5. **`Ma_Nguon_Google_Sheet_ThinClientWrapper.txt` (và `.js`):** Đoạn mã nguồn Apps Script dùng để dán vào tệp Google Sheet của môn học nhằm kết nối tự động với Thư viện trung tâm `TracNghiemCore`.
6. **`tai_lieu_chuong_template.qmd`:** Biểu mẫu tài liệu chuyên đề Quarto (.qmd) dùng cho Bước 1 (Khảo sát và xây dựng khung chuyên đề bài học).

