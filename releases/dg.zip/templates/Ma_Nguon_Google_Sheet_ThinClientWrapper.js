/**
 * ==============================================================================
 * DỰ ÁN NỀN TẢNG KHẢO THÍ VÀ NGÂN HÀNG CÂU HỎI TRẮC NGHIỆM TRỰC TUYẾN
 * ==============================================================================
 * Tệp: ThinClientWrapper.js (Mã nguồn gắn tại Google Sheet của Giảng viên)
 * Phân hệ: Thin Client Adapter
 * Tác giả cấu hình: T.M.Tường & Trợ lý Antigravity
 * Phiên bản: 3.5 (Cổng Khảo thí hợp nhất - 1 Liên kết duy nhất & Zero-hardcode)
 *
 * MÔ TẢ:
 * Đoạn mã này được gắn cố định trong tệp Google Sheet môn học.
 * Toàn bộ 100% logic xử lý, giao diện Web App và cây thư mục được nạp tự động
 * từ Master Library: TracNghiemCore.
 * ==============================================================================
 */

/** 1. Lấy ngữ cảnh làm việc {ssId, folderId} của Google Sheet hiện tại */
function ctx_() {
  var props = PropertiesService.getScriptProperties();
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var ssId = ss ? ss.getId() : props.getProperty('SS_ID');
  var folderId = props.getProperty('ROOT_FOLDER_ID');
  if (!folderId && ss) {
    try {
      var parents = DriveApp.getFileById(ss.getId()).getParents();
      if (parents.hasNext()) {
        folderId = parents.next().getId();
        props.setProperty('ROOT_FOLDER_ID', folderId);
      }
    } catch (_) {}
  }
  return { ssId: ssId, folderId: folderId };
}

/** 2. Tự động tạo menu khi mở bảng tính */
function onOpen(e) { TracNghiemCore.onOpen(e); }

/** 3. Cổng tiếp nhận Web App (doGet / doPost) */
function doGet(e) { return TracNghiemCore.doGet(e); }
function doPost(e) { return TracNghiemCore.doPost(e); }

/* ==============================================================================
 * 4. CÁC HÀM QUẢN TRỊ (GẮN TRỰC TIẾP VÀO MENU GOOGLE SHEET)
 * ============================================================================== */
function admin_bootstrap() { return TracNghiemCore.admin_bootstrap(ctx_()); }
function admin_activateExam() { return TracNghiemCore.admin_activateExam(ctx_()); }
function admin_toggleExamStatus() { return TracNghiemCore.admin_toggleExamStatus(ctx_()); }

/**
 * Tự động tìm đường link triển khai Web App chuẩn xác (Zero-hardcode)
 * Thứ tự ưu tiên:
 * 1. Gọi Apps Script REST API (projects.deployments.list) quét tìm bản deploy mới nhất
 * 2. Lấy giá trị cấu hình lưu trong trang tính CauHinh (ô B2 hoặc dòng webAppUrl)
 * 3. Lấy từ bộ nhớ dự án PropertiesService
 */
function getLatestWebAppUrl_() {
  var props = PropertiesService.getScriptProperties();

  // Tầng 1: Quét danh sách deployments qua Apps Script API nếu có quyền
  try {
    var scriptId = ScriptApp.getScriptId();
    var token = ScriptApp.getOAuthToken();
    var res = UrlFetchApp.fetch('https://script.googleapis.com/v1/projects/' + scriptId + '/deployments', {
      headers: { Authorization: 'Bearer ' + token },
      muteHttpExceptions: true
    });
    if (res.getResponseCode() === 200) {
      var data = JSON.parse(res.getContentText());
      var webApps = (data.deployments || []).filter(function(d) {
        return (d.entryPoints || []).some(function(e) { return e.entryPointType === 'WEB_APP'; });
      });
      if (webApps.length > 0) {
        webApps.sort(function(a, b) {
          return new Date(b.updateTime) - new Date(a.updateTime);
        });
        var latest = webApps[0];
        var ep = latest.entryPoints.find(function(e) { return e.entryPointType === 'WEB_APP'; });
        if (ep && ep.webApp && ep.webApp.url) {
          var apiUrl = ep.webApp.url.replace(/\/a\/[^\/]+\//, '/').split('?')[0];
          props.setProperty('WEB_APP_URL', apiUrl);
          return apiUrl;
        }
      }
    }
  } catch (_) {}

  // Tầng 2: Lấy từ sheet CauHinh do Giảng viên lưu
  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var sheetConfig = ss ? ss.getSheetByName('CauHinh') : null;
    if (sheetConfig) {
      var cData = sheetConfig.getDataRange().getValues();
      for (var i = 1; i < cData.length; i++) {
        if ((cData[i][0] || '').toString().trim() === 'webAppUrl' && cData[i][1]) {
          var u = cData[i][1].toString().trim().replace(/\/a\/[^\/]+\//, '/').split('?')[0];
          if (u.indexOf('/exec') !== -1) return u;
        }
      }
    }
  } catch (_) {}

  // Tầng 3: Lấy từ bộ nhớ cache PropertiesService
  var cached = props.getProperty('WEB_APP_URL');
  if (cached && cached.indexOf('/exec') !== -1) {
    return cached.replace(/\/a\/[^\/]+\//, '/').split('?')[0];
  }

  return null;
}

/**
 * Hiển thị cửa sổ modal cung cấp Duy nhất 1 đường link Cổng Khảo thí & Luyện tập
 */
function admin_getExamLink() {
  var ui = SpreadsheetApp.getUi();
  var portalUrl = getLatestWebAppUrl_() || '';

  if (portalUrl) {
    portalUrl = portalUrl.replace(/\/a\/[^\/]+\//, '/').split('?')[0];
  }

  var html = '<!DOCTYPE html><html><head><style>' +
    'body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; padding: 18px; color: #1e293b; line-height: 1.5; margin:0; }' +
    'h3 { color: #0284c7; margin-top: 0; margin-bottom: 8px; font-size: 16px; display: flex; align-items: center; gap: 6px; }' +
    '.desc { font-size: 12px; color: #475569; margin-bottom: 14px; }' +
    '.card { background: #f8fafc; border: 1.5px solid #cbd5e1; border-radius: 10px; padding: 14px; margin-bottom: 12px; box-shadow: 0 1px 3px rgba(0,0,0,0.05); }' +
    '.card-title { font-weight: 700; font-size: 13px; color: #0f172a; margin-bottom: 8px; }' +
    'input[type="text"] { width: 100%; box-sizing: border-box; padding: 10px; border: 1px solid #94a3b8; border-radius: 6px; font-family: monospace; font-size: 12px; background: #fff; color: #0f172a; }' +
    '.btn-row { display: flex; gap: 8px; margin-top: 10px; }' +
    '.btn-copy { flex: 1; padding: 9px 14px; background: #0284c7; color: white; border: none; border-radius: 6px; cursor: pointer; font-size: 12.5px; font-weight: 600; text-align: center; }' +
    '.btn-copy:hover { background: #0369a1; }' +
    '.btn-open { padding: 9px 14px; background: #f1f5f9; color: #0f172a; border: 1px solid #cbd5e1; border-radius: 6px; cursor: pointer; font-size: 12.5px; font-weight: 600; }' +
    '.btn-open:hover { background: #e2e8f0; }' +
    '.btn-save { padding: 8px 16px; background: #16a34a; color: white; border: none; border-radius: 6px; cursor: pointer; font-size: 12px; font-weight: 600; }' +
    '.btn-save:hover { background: #15803d; }' +
    '.btn-edit { background: none; border: none; color: #0284c7; text-decoration: underline; cursor: pointer; font-size: 11.5px; padding: 0; }' +
    '.footer { display: flex; justify-content: space-between; align-items: center; margin-top: 10px; padding-top: 10px; border-top: 1px solid #e2e8f0; font-size: 11.5px; color: #64748b; }' +
    '#editBox { display: ' + (portalUrl ? 'none' : 'block') + '; background: #fffbeb; border: 1px solid #fde68a; border-radius: 8px; padding: 12px; margin-top: 10px; }' +
    '</style></head><body>' +
    '<h3>🌐 Cổng Khảo Thí & Luyện Tập Trắc Nghiệm</h3>' +
    '<div class="desc">Thầy/cô chỉ cần gửi duy nhất đường link này cho sinh viên. Khi mở link, hệ thống sẽ hiện giao diện chào mừng để sinh viên <b>tự chọn</b> vào Thi chính thức hoặc Luyện tập tự do.</div>' +
    
    (portalUrl ? 
      '<div id="linksView">' +
      '  <div class="card">' +
      '    <div class="card-title">🔗 Đường link truy cập Cổng Khảo thí (Web App):</div>' +
      '    <input type="text" id="linkPortal" value="' + portalUrl + '" readonly onclick="this.select();">' +
      '    <div class="btn-row">' +
      '      <button class="btn-copy" onclick="copyPortalLink(this)">📋 Sao chép Liên kết gửi Sinh viên</button>' +
      '      <button class="btn-open" onclick="openPortalLink()">🚀 Mở thử nghiệm</button>' +
      '    </div>' +
      '  </div>' +
      '  <div class="footer">' +
      '    <span>✅ Đang dùng bản Deploy Web App hợp lệ.</span>' +
      '    <button class="btn-edit" onclick="document.getElementById(\'editBox\').style.display=\'block\';">✏️ Đổi URL khác</button>' +
      '  </div>' +
      '</div>'
      : '') +

    '<div id="editBox">' +
    '  <div style="font-weight: 700; font-size: 12.5px; color: #92400e; margin-bottom: 4px;">🔗 ' + (portalUrl ? 'Chỉnh sửa URL Web App:' : 'Chưa nhận diện được URL deploy. Dán URL Web App (/exec) vào đây:') + '</div>' +
    '  <input type="text" id="customUrl" placeholder="https://script.google.com/macros/s/.../exec" value="' + portalUrl + '">' +
    '  <div style="margin-top: 8px; text-align: right;">' +
    '    <button class="btn-save" onclick="saveCustomUrl()">💾 Lưu & Cập nhật link</button>' +
    '  </div>' +
    '</div>' +

    '<script>' +
    'function copyPortalLink(btn) {' +
    '  var inp = document.getElementById("linkPortal");' +
    '  inp.select();' +
    '  navigator.clipboard.writeText(inp.value);' +
    '  var old = btn.innerText;' +
    '  btn.innerText = "✅ Đã sao chép vào Clipboard!";' +
    '  setTimeout(function() { btn.innerText = old; }, 2000);' +
    '}' +
    'function openPortalLink() {' +
    '  var inp = document.getElementById("linkPortal");' +
    '  window.open(inp.value, "_blank");' +
    '}' +
    'function saveCustomUrl() {' +
    '  var val = document.getElementById("customUrl").value.trim();' +
    '  if (!val || val.indexOf("/exec") === -1) { alert("Vui lòng nhập đường link hợp lệ kết thúc bằng /exec"); return; }' +
    '  google.script.run.withSuccessHandler(function() { google.script.host.close(); }).admin_saveCustomUrl(val);' +
    '}' +
    '</script>' +
    '</body></html>';

  var output = HtmlService.createHtmlOutput(html).setWidth(540).setHeight(portalUrl ? 300 : 210);
  ui.showModalDialog(output, '🌐 Cung cấp đường link thi cho sinh viên');
}

/**
 * Lưu URL người dùng tùy chỉnh vào cả PropertiesService và trang tính CauHinh
 */
function admin_saveCustomUrl(url) {
  if (!url) return;
  var clean = url.replace(/\/a\/[^\/]+\//, '/').split('?')[0];
  PropertiesService.getScriptProperties().setProperty('WEB_APP_URL', clean);
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sheetConfig = ss ? ss.getSheetByName('CauHinh') : null;
  if (sheetConfig) {
    var found = false;
    var cData = sheetConfig.getDataRange().getValues();
    for (var r = 1; r < cData.length; r++) {
      if ((cData[r][0] || '').toString().trim() === 'webAppUrl') {
        sheetConfig.getRange(r + 1, 2).setValue(clean);
        found = true;
        break;
      }
    }
    if (!found) sheetConfig.appendRow(['webAppUrl', clean, 'Đường link Web App']);
  }
  admin_getExamLink();
}

function admin_runAnalytics() { return TracNghiemCore.admin_runAnalytics(ctx_()); }
function admin_createExam() { return TracNghiemCore.admin_createExam(ctx_()); }
function admin_openReview() { return TracNghiemCore.admin_openReview(ctx_()); }
function admin_validateAll() { return TracNghiemCore.admin_validateAll(ctx_()); }
function admin_exportQmd() { return TracNghiemCore.admin_exportQmd(ctx_()); }
function admin_checkUpdate() { return TracNghiemCore.admin_checkUpdate(ctx_()); }

/* ==============================================================================
 * 5. CÁC HÀM CẦU NỐI (PROXY CHO GOOGLE.SCRIPT.RUN TỪ WEB APP & MODALS)
 * ============================================================================== */

/* --- 5.1. Chế độ Thi chính thức (Exam Mode) --- */
function exam_getConfig() { return TracNghiemCore.exam_getConfig(ctx_()); }
function exam_start(params) { return TracNghiemCore.exam_start(ctx_(), params); }
function exam_autosave(params) { return TracNghiemCore.exam_autosave(ctx_(), params); }
function exam_logViolation(params) { return TracNghiemCore.exam_logViolation(ctx_(), params); }
function exam_submit(params) { return TracNghiemCore.exam_submit(ctx_(), params); }

/* --- 5.2. Chế độ Thực hành tự luyện (Practice Mode) --- */
function practice_getConfig() { return TracNghiemCore.practice_getConfig(ctx_()); }
function practice_listTopics() { return TracNghiemCore.practice_listTopics(ctx_()); }
function practice_listSets() { return TracNghiemCore.practice_listSets(ctx_()); }
function practice_getQuestions(params) { return TracNghiemCore.practice_getQuestions(ctx_(), params); }
function practice_log(params) { return TracNghiemCore.practice_log(ctx_(), params); }
function practice_reportBug(params) { return TracNghiemCore.practice_reportBug(ctx_(), params); }

/* --- 5.3. Modal Duyệt đề thô (DuyetDeThoUI) --- */
function review_getDraftTopics() { return TracNghiemCore.review_getDraftTopics(ctx_()); }
function review_approveQuestion(params) { return TracNghiemCore.review_approveQuestion(ctx_(), params); }
function review_approveAllClean(topicId) { return TracNghiemCore.review_approveAllClean(ctx_(), topicId); }
function review_rejectQuestion(params) { return TracNghiemCore.review_rejectQuestion(ctx_(), params); }
function review_updateDraftQuestion(params) { return TracNghiemCore.review_updateDraftQuestion(ctx_(), params); }
function review_deleteDraftQuestion(params) { return TracNghiemCore.review_deleteDraftQuestion(ctx_(), params); }

/* --- 5.4. Modal Tạo đề thi chính thức (TaoDeThiUI) --- */
function modal_submitCreateExam(blueprint) { 
  return TracNghiemCore.admin_submitCreateExamFromUI(ctx_(), blueprint); 
}
