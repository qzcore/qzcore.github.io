# Mẫu soạn câu hỏi trắc nghiệm bằng Markdown (Manual Authoring Template)

> **Hướng dẫn sử dụng:**
> - Mỗi câu hỏi được bao bọc trong cặp thẻ `<!-- QUESTION_START -->` và `<!-- QUESTION_END -->`.
> - Giảng viên có thể soạn trực tiếp bằng trình soạn thảo Markdown, sau đó nhờ AI hoặc script chuyển đổi sang định dạng JSON để đưa vào `01_ngan_hang_de_tho/`.
> - Để nhờ AI soạn nhanh hơn, vui lòng tham khảo tệp [`prompt-ai-tao-de.md`](./prompt-ai-tao-de.md).

---

## Cấu trúc chuẩn của một câu hỏi

```markdown
<!-- QUESTION_START -->
ID: [MÃ_MÔN]_[MÃ_CHỦ_ĐỀ]_[SỐ_TT]
Môn học: [MÃ_MÔN]
Chương: [TÊN_CHƯƠNG_HOẶC_CHỦ_ĐỀ]
Mục con (subTopic): [TÊN_MỤC_CON_BÀI_HỌC, ví dụ: 1.1 Khái niệm cơ bản]
Mức độ: [Nhan_biet_Thong_hieu | Van_dung | Van_dung_cao]
Điểm: 0.5
Thẻ: [tag1, tag2]

**Câu hỏi:**
[Nội dung câu hỏi. Hỗ trợ công thức toán KaTeX $...$, $$...$$ hoặc khối mã lập trình ```python ... ```]

A. [Nội dung phương án A]
B. [Nội dung phương án B]
C. [Nội dung phương án C]
D. [Nội dung phương án D]

**Đáp án đúng:** [A | B | C | D]

**Giải thích phương án:**
- Phương án A: [✅ hoặc ❌ kèm lý do cụ thể, không nhắc lại ký hiệu A/B/C/D]
- Phương án B: [✅ hoặc ❌ kèm bẫy sai lầm]
- Phương án C: [✅ hoặc ❌ kèm bẫy sai lầm]
- Phương án D: [✅ hoặc ❌ kèm bẫy sai lầm]

**Kiến thức mở rộng (tùy chọn):**
[Kiến thức bổ trợ hiển thị cho sinh viên trong chế độ Thực hành]
<!-- QUESTION_END -->
```

---

## Ví dụ mẫu minh họa

### Ví dụ 1: Câu hỏi tính toán kinh tế có công thức KaTeX

<!-- QUESTION_START -->
ID: TKT_C02_108
Môn học: Toan_Kinh_Te
Chương: Chương 2: Toán tài chính căn bản
Mục con (subTopic): 2.1 Phương thức lãi đơn và lãi kép
Mức độ: Nhan_biet_Thong_hieu
Điểm: 0.5
Thẻ: lai_don, lai_suat

**Câu hỏi:**
Một cá nhân gửi khoản vốn $80$ triệu đồng vào ngân hàng theo phương thức lãi đơn. Sau $2.5$ năm, người đó tất toán tài khoản và nhận về tổng số tiền (cả vốn và lãi) là $96$ triệu đồng. Mức lãi suất đơn hàng năm của khoản tiền gửi này là:

A. $8\%$/năm
B. $20\%$/năm
C. $6.67\%$/năm
D. $10\%$/năm

**Đáp án đúng:** A

**Giải thích phương án:**
- Phương án A: ✅ Đúng. Tiền lãi $I = 96 - 80 = 16$ triệu đồng. Áp dụng công thức lãi đơn $I = P \cdot r \cdot t \implies r = \frac{16}{80 \times 2.5} = 8\%$/năm.
- Phương án B: ❌ Sai. Lấy tổng tỷ lệ sinh lời cho cả kỳ $2.5$ năm $\frac{16}{80} = 20\%$ mà quên chia cho thời gian $t = 2.5$ năm.
- Phương án C: ❌ Sai. Chia nhầm cho tổng số tiền đáo hạn $96$ triệu đồng thay vì vốn gốc ban đầu $80$ triệu đồng.
- Phương án D: ❌ Sai. Tính nhầm thời gian $t = 2$ năm thay vì $2.5$ năm.

**Kiến thức mở rộng:**
Trong các giao dịch tài chính ngắn hạn, lãi đơn được áp dụng phổ biến trên vốn gốc ban đầu không đổi.
<!-- QUESTION_END -->

---

### Ví dụ 2: Câu hỏi lập trình và khoa học dữ liệu

<!-- QUESTION_START -->
ID: PY_C02_105
Môn học: Python_KHDL
Chương: Chương 2: Cấu trúc dữ liệu và mảng NumPy
Mục con (subTopic): 2.2 Thao tác cắt lát và quản lý bộ nhớ
Mức độ: Van_dung
Điểm: 0.5
Thẻ: numpy, indexing, view_copy

**Câu hỏi:**
Cho mảng NumPy 1 chiều `a = np.array([10, 20, 30, 40, 50])`. Thao tác nào sau đây tạo ra một **view** (chia sẻ vùng nhớ) mà không tạo bản sao độc lập (copy)?

A. `b = a[1:4]`
B. `b = a[[1, 3]]`
C. `b = a[a > 25]`
D. `b = a.copy()`

**Đáp án đúng:** A

**Giải thích phương án:**
- Phương án A: ✅ Đúng. Thao tác cắt lát cơ bản (Basic slicing `a[start:stop]`) trong NumPy luôn tạo ra view, thay đổi trên `b` sẽ ảnh hưởng trực tiếp đến mảng gốc `a`.
- Phương án B: ❌ Sai. Fancy indexing (truy xuất bằng danh sách chỉ số) luôn tạo ra một mảng hoàn toàn mới trong bộ nhớ (copy).
- Phương án C: ❌ Sai. Lọc mảng bằng mảng boolean (Boolean indexing) luôn sao chép dữ liệu ra vùng nhớ mới vì kích thước kết quả phụ thuộc dữ liệu.
- Phương án D: ❌ Sai. Phương thức `.copy()` chủ động nhân bản một mảng dữ liệu riêng biệt.
<!-- QUESTION_END -->

