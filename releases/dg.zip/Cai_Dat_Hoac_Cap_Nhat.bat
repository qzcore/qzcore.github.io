@echo off
chcp 65001 > nul
setlocal enabledelayedexpansion

title TRÌNH CÀI ĐẶT & CẬP NHẬT BỘ CÔNG CỤ KHẢO THÍ (v5.0)

echo ==================================================================
echo   🚀 TRÌNH CÀI ĐẶT & CẬP NHẬT BỘ CÔNG CỤ KHẢO THÍ THÔNG MINH (v5.0)
echo ==================================================================

:: 1. Kiểm tra Python
where python >nul 2>nul
if %errorlevel% equ 0 (
    if exist "%~dp0dong_goi\scripts\cai_dat_hoac_cap_nhat.py" (
        python "%~dp0dong_goi\scripts\cai_dat_hoac_cap_nhat.py" %*
        goto :eof
    )
    if exist "%~dp0cai_dat_hoac_cap_nhat.py" (
        python "%~dp0cai_dat_hoac_cap_nhat.py" %*
        goto :eof
    )
)

where py >nul 2>nul
if %errorlevel% equ 0 (
    if exist "%~dp0dong_goi\scripts\cai_dat_hoac_cap_nhat.py" (
        py -3 "%~dp0dong_goi\scripts\cai_dat_hoac_cap_nhat.py" %*
        goto :eof
    )
    if exist "%~dp0cai_dat_hoac_cap_nhat.py" (
        py -3 "%~dp0cai_dat_hoac_cap_nhat.py" %*
        goto :eof
    )
)

:: 2. Fallback bằng PowerShell tích hợp sẵn trên Windows nếu máy chưa cài Python
echo Đang chạy trình cài đặt thông minh qua PowerShell tích hợp...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
    "$scriptPath = '%~dp0'; ^
    $zipFiles = Get-ChildItem -Path $scriptPath -Filter '*.zip' -Recurse | Where-Object { $_.Name -like 'dg*.zip' -or $_.Name -like '*.zip' } | Sort-Object LastWriteTime -Descending; ^
    if ($zipFiles.Count -eq 0) { Write-Host '❌ Không tìm thấy tệp .zip cập nhật!' -ForegroundColor Red; Read-Host 'Bấm Enter để thoát'; exit 1 }; ^
    $zipSource = $zipFiles[0].FullName; ^
    Write-Host ('📦 Phát hiện gói phần mềm: ' + $zipFiles[0].Name) -ForegroundColor Cyan; ^
    $targetName = Read-Host 'Nhập tên môn học của Thầy/Cô (mặc định: Toan_kinh_te)'; ^
    if ([string]::IsNullOrWhiteSpace($targetName)) { $targetName = 'Toan_kinh_te' }; ^
    $targetDir = Join-Path $scriptPath $targetName; ^
    $dataFolders = @('00_du_lieu_ra_de','01_ngan_hang_de_tho','02_ngan_hang_de','03_de_thi','04_de_thuc_hanh','05_xuat_ban_pdf'); ^
    $hasExisting = Test-Path $targetDir; ^
    $skipped = 0; $updated = 0; ^
    if ($hasExisting) { ^
        Write-Host '🛡️ KÍCH HOẠT CHẾ ĐỘ BẢO VỆ NGÂN HÀNG CÂU HỎI...' -ForegroundColor Green; ^
        $backupDir = Join-Path $targetDir ('_backup_' + (Get-Date -Format 'yyyyMMdd_HHmmss')); ^
        $oldTool = Join-Path $targetDir '06_duyet_va_tao_de'; ^
        if (Test-Path $oldTool) { Copy-Item -Path $oldTool -Destination (Join-Path $backupDir '06_duyet_va_tao_de') -Recurse -Force }; ^
    }; ^
    Add-Type -AssemblyName System.IO.Compression.FileSystem; ^
    $zip = [System.IO.Compression.ZipFile]::OpenRead($zipSource); ^
    foreach ($entry in $zip.Entries) { ^
        if ($entry.FullName.EndsWith('/') -or $entry.FullName.Contains('__MACOSX')) { continue }; ^
        $destFile = Join-Path $targetDir $entry.FullName; ^
        $relFirst = ($entry.FullName -split '[/\\]')[0]; ^
        if ($hasExisting -and ($dataFolders -contains $relFirst) -and (Test-Path $destFile)) { ^
            $skipped++; continue; ^
        }; ^
        $parent = Split-Path $destFile; ^
        if (!(Test-Path $parent)) { New-Item -ItemType Directory -Path $parent -Force | Out-Null }; ^
        [System.IO.Compression.ZipFileExtensions]::ExtractToFile($entry, $destFile, $true); ^
        $updated++; ^
    }; ^
    $zip.Dispose(); ^
    foreach ($df in $dataFolders) { $p = Join-Path $targetDir $df; if (!(Test-Path $p)) { New-Item -ItemType Directory -Path $p -Force | Out-Null } }; ^
    $baiTap = Join-Path $targetDir '04_de_thuc_hanh\bai_tap'; if (!(Test-Path $baiTap)) { New-Item -ItemType Directory -Path $baiTap -Force | Out-Null }; ^
    Write-Host '🎉 HOÀN TẤT!' -ForegroundColor Green; ^
    Write-Host ('   • Đã nâng cấp công cụ: ' + $updated + ' tệp.') -ForegroundColor Cyan; ^
    Write-Host ('   • ĐÃ BẢO TỒN NGUYÊN VẸN: ' + $skipped + ' tệp dữ liệu của Thầy/Cô.') -ForegroundColor Green; ^
    $appHtml = Join-Path $targetDir 'Duyet_va_tao_de.html'; ^
    if (!(Test-Path $appHtml)) { $appHtml = Join-Path $targetDir '06_duyet_va_tao_de\Duyet_va_tao_de.html' }; ^
    if (Test-Path $appHtml) { Start-Process $appHtml }; ^
    Read-Host 'Bấm Enter để hoàn tất';"

pause

