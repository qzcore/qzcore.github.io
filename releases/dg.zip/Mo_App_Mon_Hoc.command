#!/usr/bin/env bash
# ==============================================================================
# KHỞI CHẠY ỨNG DỤNG KHẢO THÍ & SOẠN ĐỀ (STANDALONE APP MODE / PWA)
# ==============================================================================
DIR="$(cd "$(dirname "$0")" && pwd)"
HTML_PATH="$DIR/06_duyet_va_tao_de/Duyet_va_tao_de.html"

# Tự động dọn dẹp thư mục profile cũ nếu có để tránh Chrome chặn bảo mật thư mục hệ thống
if [ -d "$DIR/.app_profile" ]; then
  rm -rf "$DIR/.app_profile"
fi

if [ ! -f "$HTML_PATH" ]; then
  HTML_PATH="$DIR/Duyet_va_tao_de.html"
fi

if [ ! -f "$HTML_PATH" ]; then
  echo "❌ Không tìm thấy tệp Duyet_va_tao_de.html!"
  exit 1
fi

echo "🚀 Đang mở Ứng dụng Khảo thí ở chế độ Cửa sổ độc lập (PWA App Mode)..."

# 1. Tìm đường dẫn thực thi trình duyệt Chromium trên macOS
CHROME_BIN="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
EDGE_BIN="/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge"
BRAVE_BIN="/Applications/Brave Browser.app/Contents/MacOS/Brave Browser"

APP_FLAGS=(--app="file://$HTML_PATH")

if [ -f "$CHROME_BIN" ]; then
  open -n -a "/Applications/Google Chrome.app" --args "${APP_FLAGS[@]}" 2>/dev/null || "$CHROME_BIN" "${APP_FLAGS[@]}" >/dev/null 2>&1 &
elif [ -f "$EDGE_BIN" ]; then
  open -n -a "/Applications/Microsoft Edge.app" --args "${APP_FLAGS[@]}" 2>/dev/null || "$EDGE_BIN" "${APP_FLAGS[@]}" >/dev/null 2>&1 &
elif [ -f "$BRAVE_BIN" ]; then
  open -n -a "/Applications/Brave Browser.app" --args "${APP_FLAGS[@]}" 2>/dev/null || "$BRAVE_BIN" "${APP_FLAGS[@]}" >/dev/null 2>&1 &
else
  # Mở bằng trình duyệt mặc định nếu không có Chromium
  open "$HTML_PATH"
fi

# Tự động đóng cửa sổ terminal sau khi khởi chạy
osascript -e 'tell application "Terminal" to close (every window whose name contains "Mo_App_Mon_Hoc")' >/dev/null 2>&1 &
exit 0
