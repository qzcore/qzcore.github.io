# Thư mục 05: Xuất bản đề thi in ấn Quarto/PDF

Thư mục này phục vụ công tác in ấn đề thi giấy cho các kỳ thi tập trung tại giảng đường:

- **Định dạng mặc định:** PDF (biên dịch bằng Quarto).
- **Lệnh thực thi:**
  ```bash
  quarto render de_thi.qmd --to pdf
  ```
- **Hai phiên bản đề thi:**
  1. **Bản sinh viên (Đề phát cho thí sinh):** Ẩn đáp án đúng, ẩn phần giải thích chi tiết, định dạng 2 cột tiết kiệm giấy in.
  2. **Bản giảng viên / Ban khảo thí:** Đánh dấu đáp án đúng, in kèm bảng đáp án ma trận (Answer Key) và lời giải chi tiết.

