#!/usr/bin/env bash
# ==============================================================================
# SMART INSTALLER & SAFE UPDATER (macOS / Linux - Zero-Dependency)
# ==============================================================================
# Tự động nhận diện:
#   1. Ưu tiên dùng Python nếu máy có sẵn.
#   2. Fallback sang lệnh Bash + unzip chuẩn mặc định của macOS/Linux (100% không cần cài Python).
#   3. Bảo vệ tuyệt đối 100% ngân hàng câu hỏi và đề thi cũ của Thầy/Cô.
# ==============================================================================
set -e

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# 1. Ưu tiên gọi Python nếu máy có sẵn
if command -v python3 >/dev/null 2>&1; then
    if [ -f "$DIR/cai_dat_hoac_cap_nhat.py" ]; then
        python3 "$DIR/cai_dat_hoac_cap_nhat.py" "$@"
        exit 0
    elif [ -f "$DIR/dong_goi/scripts/cai_dat_hoac_cap_nhat.py" ]; then
        python3 "$DIR/dong_goi/scripts/cai_dat_hoac_cap_nhat.py" "$@"
        exit 0
    fi
fi

# 2. Chế độ Native macOS / Linux (Hoàn toàn không cần Python)
echo "=================================================================="
echo "  🚀 TRÌNH CÀI ĐẶT & CẬP NHẬT BỘ CÔNG CỤ KHẢO THÍ THÔNG MINH (v5.0)"
echo "  (Chế độ Native macOS/Linux — 100% Không yêu cầu cài đặt Python)"
echo "=================================================================="

# Tìm tệp zip nguồn
ZIP_SOURCE=""
for candidate in "$DIR"/dg*.zip "$DIR"/*.zip "$DIR"/dist/dg*.zip "$DIR"/../dist/dg*.zip; do
    if [ -f "$candidate" ]; then
        ZIP_SOURCE="$candidate"
        break
    fi
done

if [ -z "$ZIP_SOURCE" ] || [ ! -f "$ZIP_SOURCE" ]; then
    echo "❌ Lỗi: Không tìm thấy tệp gói cập nhật (.zip)."
    echo "   Vui lòng để tệp 'dg.zip' hoặc 'dg_beta.zip' cùng thư mục và thử lại."
    read -p "Bấm Enter để thoát..."
    exit 1
fi

echo "📦 Phát hiện gói phần mềm: $(basename "$ZIP_SOURCE")"

# Xác định thư mục môn học đích
if [ -d "$DIR/06_duyet_va_tao_de" ]; then
    TARGET_DIR="$DIR"
else
    DEFAULT_COURSE="Toan_kinh_te"
    echo ""
    read -p "Nhập tên thư mục môn học của Thầy/Cô (mặc định: '$DEFAULT_COURSE'): " USER_COURSE
    COURSE_NAME="${USER_COURSE:-$DEFAULT_COURSE}"
    TARGET_DIR="$DIR/$COURSE_NAME"
fi

echo "📁 Thư mục môn học đích: $TARGET_DIR"

DATA_FOLDERS=("00_du_lieu_ra_de" "01_ngan_hang_de_tho" "02_ngan_hang_de" "03_de_thi" "04_de_thuc_hanh" "05_xuat_ban_pdf")

if [ -d "$TARGET_DIR" ]; then
    echo ""
    echo "🛡️  CHẾ ĐỘ: CẬP NHẬT AN TOÀN (Bảo tồn nguyên vẹn ngân hàng đề có sẵn)"
    BACKUP_DIR="$TARGET_DIR/_backup_$(date +%Y%m%d_%H%M%S)"
    if [ -d "$TARGET_DIR/06_duyet_va_tao_de" ]; then
        mkdir -p "$BACKUP_DIR"
        cp -R "$TARGET_DIR/06_duyet_va_tao_de" "$BACKUP_DIR/"
        echo "   -> Đã sao lưu dự phòng công cụ cũ vào: $(basename "$BACKUP_DIR")/"
    fi

    TMP_EXTRACT=$(mktemp -d 2>/dev/null || mktemp -d -t 'qz_update')
    unzip -q -o "$ZIP_SOURCE" -d "$TMP_EXTRACT"

    # Copy có chọn lọc: Bỏ qua các file thuộc DATA_FOLDERS nếu đã tồn tại
    find "$TMP_EXTRACT" -type f | while read -r src_file; do
        rel_path="${src_file#$TMP_EXTRACT/}"
        dest_file="$TARGET_DIR/$rel_path"
        first_folder=$(echo "$rel_path" | cut -d'/' -f1)

        is_data=0
        for df in "${DATA_FOLDERS[@]}"; do
            if [ "$first_folder" = "$df" ]; then
                is_data=1
                break
            fi
        done

        if [ "$is_data" -eq 1 ] && [ -f "$dest_file" ]; then
            continue
        fi

        mkdir -p "$(dirname "$dest_file")"
        cp "$src_file" "$dest_file"
    done

    rm -rf "$TMP_EXTRACT"
else
    echo ""
    echo "🌱 CHẾ ĐỘ: CÀI ĐẶT LẦN ĐẦU (Khởi tạo môn học mới)"
    mkdir -p "$TARGET_DIR"
    unzip -q -o "$ZIP_SOURCE" -d "$TARGET_DIR"
fi

# Đảm bảo đầy đủ cây thư mục chuẩn
for df in "${DATA_FOLDERS[@]}"; do
    mkdir -p "$TARGET_DIR/$df"
done
mkdir -p "$TARGET_DIR/04_de_thuc_hanh/bai_tap"
mkdir -p "$TARGET_DIR/06_duyet_va_tao_de"

echo ""
echo "🎉 HOÀN TẤT THÀNH CÔNG VÀ BẢO TỒN DỮ LIỆU TUYỆT ĐỐI!"
echo "   • Đã nâng cấp công cụ Duyet_va_tao_de.html lên phiên bản mới nhất."
echo "   • Toàn bộ ngân hàng câu hỏi và đề thi trong thư mục được bảo vệ 100%."

APP_HTML="$TARGET_DIR/Duyet_va_tao_de.html"
if [ ! -f "$APP_HTML" ]; then
    APP_HTML="$TARGET_DIR/06_duyet_va_tao_de/Duyet_va_tao_de.html"
fi

if [ -f "$APP_HTML" ]; then
    echo "🌐 Đang mở ứng dụng trên trình duyệt..."
    if command -v open >/dev/null 2>&1; then
        open "$APP_HTML"
    elif command -v xdg-open >/dev/null 2>&1; then
        xdg-open "$APP_HTML"
    fi
fi
