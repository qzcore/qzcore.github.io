# Cẩm nang Hướng dẫn Sử dụng Hệ sinh thái Khảo thí Trắc nghiệm (v5.0)

> **Tác giả phát triển phần mềm:** Thầy T.M. Tường & Trợ lý AI Antigravity (Google DeepMind)  
> **Dành cho:** Giảng viên, Giáo viên phổ thông, Trợ giảng và Quản trị viên Khảo thí.  
> **Kiến trúc v5.0:** 100% thao tác tại máy tính cá nhân qua ứng dụng `Duyet_va_tao_de.html`, kết nối tự động với Google Workspace Cloud Gateway qua REST API (Zero Drag & Drop).

---

## 1. Nơi lưu trữ tài liệu hướng dẫn trong hệ thống

Hệ sinh thái phân chia tài liệu hướng dẫn thành 3 cấp độ phù hợp cho từng đối tượng:

1. **Dành cho Giảng viên nhận gói môn học xuất xưởng (`dg.zip`):**
   - Tệp [`HUONG_DAN_CAI_DAT_GOOGLE_SHEET.md`](./HUONG_DAN_CAI_DAT_GOOGLE_SHEET.md): Hướng dẫn kích hoạt Web App trong 3 phút.
   - Tệp [`README.md`](./README.md): Cấu trúc 7 thư mục môn học (từ `00_du_lieu_ra_de` đến `06_duyet_va_tao_de`).
   - Tệp [`06_duyet_va_tao_de/README.md`](./06_duyet_va_tao_de/README.md): Hướng dẫn sử dụng phần mềm duyệt và tạo đề offline.
2. **Dành cho Quản trị viên và Kỹ thuật viên bảo trì hệ thống:**
   - Thư mục [`SPEC/`](../SPEC/): 16 mô-đun đặc tả kỹ thuật kiến trúc, giao thức REST API, thuật toán chia câu hỏi và mô hình dữ liệu.
   - Tệp [`docs/quy_chuan_phat_trien_va_quan_ly_moi_truong.qmd`](./quy_chuan_phat_trien_va_quan_ly_moi_truong.qmd): Quy chuẩn DevOps 4 bước (Local Code & Test ➔ Git ➔ Staging UFM ➔ Prod Gmail).
3. **Cẩm nang tổng quan tại tệp này:** Hướng dẫn toàn diện từ cài đặt lần đầu đến vận hành phòng thi trực tiếp và giao bài tập tuần.

---

## 2. Quy trình Cài đặt Ban đầu (Chỉ làm 1 lần — khoảng 3 phút)

### Bước 1 — Tạo bản sao Google Sheet & Triển khai Web App
1. Truy cập đường link bản sao do tác giả cung cấp: `https://docs.google.com/spreadsheets/d/<MASTER_ID>/copy`, bấm **Tạo bản sao (Make a copy)**.
2. Đổi tên bảng tính theo tên môn học (ví dụ: `KhaoThi_ToanKinhTe_2026`).
3. Mở menu: **Tiện ích mở rộng (Extensions) → Apps Script**.
4. **Cấp quyền Drive & Khởi tạo thư mục (Làm 1 lần duy nhất):**
   - Trên thanh công cụ Apps Script (cạnh "Gỡ lỗi"), chọn hàm: **`admin_bootstrap`**.
   - Bấm nút **▶ Chạy (Run)**.
   - Khi Google yêu cầu, bấm: **Xem lại quyền ➔ Tài khoản của mình ➔ Nâng cao (Advanced) ➔ Đi tới dự án (không an toàn) ➔ Cho phép (Allow)**.
   - Script chạy hoàn tất sẽ tự tạo 7 thư mục Google Drive (`00_` đến `06_`) và các bảng tính chuẩn.
5. Ở góc phải màn hình Apps Script, bấm nút xanh **Triển khai (Deploy) → Tùy chọn triển khai mới (New deployment)**:
   - Chọn loại: **Ứng dụng web (Web app)**.
   - Thực thi dưới dạng: **Tôi (Me)**.
   - Ai có quyền truy cập: **Bất kỳ ai (Anyone)**.
   - Bấm **Triển khai (Deploy)**.
6. Sao chép **Đường link ứng dụng web** (kết thúc bằng `/exec`).
*(Bảng tính hoạt động ở chế độ Cơ sở dữ liệu tĩnh - Headless Database, hoàn toàn không cần mở ra hay tương tác menu nào trên Sheet)*.

### Bước 2 — Ghép đôi tự động với ứng dụng máy tính (Zero-Knowledge Pairing)
1. Mở thư mục môn học, vào thư mục `06_duyet_va_tao_de/` và nhấp đúp tệp **`Duyet_va_tao_de.html`** (bằng Google Chrome hoặc Microsoft Edge).
2. **Đăng ký thông tin Giảng viên (Chỉ làm lần đầu):**
   - Hộp thoại cam kết bảo vệ dữ liệu và đăng ký thông tin Giảng viên sẽ tự động hiển thị.
   - Thầy/Cô điền: *Họ tên, Đơn vị/Trường, Tên môn học, Email*. Thông tin này sẽ tự động lưu và có thể cập nhật bất kỳ lúc nào qua nút **`👤 Giảng viên & Môn học`** trên thanh công cụ.
3. Chuyển sang thẻ **"🌐 Quản trị Cloud"**:
   - Dán đường link Web App vào ô *Google Apps Script Web App URL*.
   - Ô *Mã bí mật Quản trị*: **Để trống** (không cần nhập).
4. Bấm nút **"🚀 Khởi tạo Drive"**:
   - Cloud Gateway tự động tạo đầy đủ **7 thư mục chuẩn tắc** (`00_du_lieu_ra_de` đến `06_sao_luu`) và các trang tính dữ liệu.
   - **Vị trí thư mục:** Các thư mục này được tạo **nằm cùng thư mục với tệp Google Sheet** trên Google Drive của Thầy/Cô.
   - Hệ thống tự động sinh mã bảo mật và ghép đôi trực tiếp về máy tính của Thầy/Cô.
   - Huy hiệu trạng thái chuyển sang **"🟢 Đã kết nối"**.
5. Hoàn tất! Kể từ đây, mọi quyền điều khiển phòng thi, đẩy đề và xem sổ điểm đều vận hành 100% tại ứng dụng máy tính cá nhân.

> [!IMPORTANT]
> **Cấp quyền truy cập Google Drive lần đầu:**
> Khi bấm "🚀 Khởi tạo Drive" hoặc chạy Web App lần đầu, nếu Google hiển thị thông báo *Xem xét quyền (Review Permissions)*, Thầy/Cô chỉ cần bấm:
> **Tài khoản của mình ➔ Nâng cao (Advanced) ➔ Đi tới dự án (Go to... unsafe) ➔ Cho phép (Allow)**.

> [!NOTE]
> Sau bước này, thông tin kết nối sẽ được lưu an toàn trong trình duyệt của máy tính. Thầy/Cô **không bao giờ cần phải mở lại Google Sheet hay Apps Script nữa**!

---

## 3. Công cụ Chẩn đoán & Hỗ trợ kỹ thuật: Bảng điều khiển "📜 Nhật ký"

Ứng dụng `Duyet_va_tao_de.html` tích hợp sẵn **Trung tâm Chẩn đoán & Nhật ký thao tác (Audit Log & Diagnostics Console)**:
- Nút **`📜 Nhật ký`** nằm ngay trên thanh trên cùng (Top Bar), tự động đổi sang màu đỏ kèm số đếm lỗi khi phát hiện sự cố.
- **Tính năng nổi bật:**
  1. **Lọc thông minh:** Lọc nhanh theo 4 tab: *Tất cả*, *Lỗi & Cảnh báo*, *Cloud API*, *Thao tác Đề*.
  2. **1-Click Gửi Hỗ trợ:** Bấm nút **"📋 Sao chép nhật ký gửi Zalo cho Tác giả"** để gửi nhanh toàn bộ thông số kỹ thuật, phiên bản và mã lỗi cho Tác giả giải quyết tức thì.
  3. **Tải tệp nhật ký:** Bấm nút **"📥 Tải tệp nhật ký (.txt)"** để lưu trữ vết vận hành.

---

## 4. Phân hệ Thí sinh: Xác thực Google One-Tap & Webcam Check-in

Khi sinh viên mở đường link phòng thi trực tuyến (`WebClient.html`):

1. **Xác thực Đăng nhập Thông minh:**
   - Hỗ trợ hộp thoại **Google One-Tap / Google Sign-In** tự động nhận diện tài khoản Google (email sinh viên trường `@ufm.edu.vn` hoặc Gmail).
   - Tự động điền trước Họ tên và Email; sinh viên chỉ cần xác nhận MSSV và Lớp.
2. **Webcam Check-in Điểm danh Khuôn mặt (Anti-cheat):**
   - Sinh viên cấp quyền camera để chụp ảnh chân dung check-in trước khi nhận đề thi.
   - Ảnh chân dung được tự động nén tối ưu dung lượng và **in chìm Watermark động** (MSSV, Họ tên, Email, Thời gian thực) chống chụp ảnh màn hình hoặc quay lén.
   - Ảnh check-in được gửi kèm bài làm lên Google Drive để giảng viên đối chiếu danh tính.

---

## 3. Quy trình Vận hành Thường ngày (100% trên ứng dụng máy tính)

```mermaid
flowchart TD
    A["1. Thẩm định & Duyệt câu hỏi\n(Tab 1: Thẩm định 11 tiêu chuẩn V01-V11)"] --> B["2. Sinh đề thi 60/30/10\n(Tab 2: Tạo đề thi & Chia mã đề)"]
    B --> C["3. Bấm '🚀 Đẩy lên Cloud & Kích hoạt'\n(Tự động bay lên Drive & Mở phòng thi)"]
    C --> D["4. Cho sinh viên quét mã QR\n(Tab 4: Quét mã QR hoặc chép link)"]
    D --> E["5. Xem điểm thời gian thực & Xuất Excel\n(Tab 4: Sổ điểm & Thống kê phổ điểm)"]
```

### Cổng Khảo thí Hợp nhất của Sinh viên
Khi Thầy/Cô gửi đường link Web App chính (`https://script.google.com/macros/s/.../exec`), sinh viên truy cập sẽ thấy ngay màn hình Cổng chào với **3 lựa chọn rõ ràng**:
1. **🎯 1. Vào thi chính thức (Exam Mode):** Điểm danh, xác thực Google GIS, webcam check-in và làm bài thi có giám sát anti-cheat.
2. **📚 2. Làm bài tập theo tuần (Assignment Mode):** Nhập MSSV, chọn bài tập tuần và làm bài tập định hướng có hiển thị đáp án, lời giải chi tiết 3 phần để tự học và chốt chuyên cần đúng hạn.
3. **⚡ 3. Luyện tập tự do (Practice Mode):** Tự do chọn chủ đề / bài học con để ôn luyện, xem ngay lời giải và luyện lại câu sai mà không bị giới hạn thời gian.

*(Thầy/Cô cũng có thể gửi liên kết chỉ định trực tiếp cho từng chế độ tại Tab 4 "Quản trị Cloud": `?mode=exam`, `?mode=assignment` hoặc `?mode=practice`)*.

### Chế độ 1: Tổ chức Kỳ thi Chính thức (Exam Mode)
1. Tại **Tab 2 (Tạo đề thi)**, chọn số câu, ma trận độ khó (NB-TH-VD-VDC), thuật toán tráo Fisher-Yates.
2. Bấm **"Lưu đề thi"** ➔ Hộp thoại xác nhận hiện ra.
3. Bấm nút **"🚀 Đẩy lên Cloud & Mở phòng thi ngay (1-chạm)"**:
   - Tệp đề thi tự động tải lên thư mục `03_de_thi/` trên Google Drive.
   - Phòng thi tự động chuyển sang trạng thái **🟢 Đang mở thi**.
   - Trình duyệt tự chuyển sang **Tab 4 (Quản trị Cloud)**, hiển thị mã QR Code cho sinh viên quét vào thi ngay.
4. Bấm **"🔄 Tải kết quả mới nhất"** để xem danh sách sinh viên nộp bài, điểm số và số lần vi phạm rời màn hình.
5. Khi hết giờ, bấm **"🔴 Đóng phòng thi"** và bấm **"📥 Xuất file Excel/CSV"** để lưu bảng điểm về máy.

### Chế độ 2: Tổ chức Bài tập Tuần có Deadline (Assignment Mode)
1. Chuyển sang **Tab 3 (Bài tập tự học)**, chọn mã bài tập (ví dụ: `BT_Tuan03`), tên bài tập và hạn nộp (Deadline).
2. Lựa chọn câu hỏi từ kho câu hỏi đã duyệt.
3. Bấm **"🚀 Đẩy lên Cloud"**:
   - Tệp bài tập tự động bay vào thư mục `04_de_thuc_hanh/bai_tap/` trên Google Drive.
4. Gửi đường link bài tập tuần (`?mode=assignment`) cho lớp.
5. Sinh viên nhập MSSV làm bài; hệ thống tự động đối chiếu Deadline và ghi nhận trạng thái **`HOAN_THANH`** hoặc **`NOP_TRE`** vào sheet `TheoDoi_BaiTap`.

### Chế độ 3: Luyện tập Tự do Ẩn danh (Practice Mode)
- Sinh viên truy cập link `?mode=practice` để tự do chọn chủ đề (Topic) hoặc bài học con (`subTopic`), làm bài và nhận ngay giải thích chi tiết 3 phần mà không bị chấm điểm hay ghi danh.

---

## 4. Chu trình 2 bước Biên soạn & Khảo sát Học liệu Chuẩn hóa

Hệ thống hỗ trợ Trợ lý AI Antigravity tích hợp sẵn chu trình 2 bước tiếp ứng khép kín:

1. **Bước 1 — Khảo sát & Xuất bản Dữ liệu Chuyên đề Quarto (`00_du_lieu_ra_de/`):**
   - Giảng viên yêu cầu: *"Khảo sát và lập cây chuyên đề Chương X cho môn Y"*.
   - Trợ lý AI tự động tra cứu chương trình học chuẩn (GDPT 2018 hoặc Đề cương Đại học), thiết lập Cây chuyên đề 2 cấp độ (Chương ➔ 3 đến 5 chuyên đề con bài học tuần).
   - Tự động xuất bản tệp tài liệu Quarto: `00_du_lieu_ra_de/tai_lieu_<Mã_chương>_<Tên_chương>.qmd`. Tệp này là Nguồn chân lý duy nhất (Single Source of Truth) chứa YCCĐ, lý thuyết, công thức KaTeX và các bẫy tư duy kinh điển. Thầy/Cô có thể dùng Quarto biên dịch ra PDF để in phát cho sinh viên.
2. **Bước 2 — Tiếp ứng Biên soạn Câu hỏi có Phân cấp `subTopic` (`01_ngan_hang_de_tho/`):**
   - Giảng viên yêu cầu: *"Soạn 15 câu Chương X"* hoặc *"Soạn 5 câu cho mục X.Y"*.
   - Trợ lý AI tự động đọc tệp `.qmd` trong `00_`, sinh các câu hỏi đạt chuẩn V01-V11 có gắn nhãn `subTopic` và phân chia dải ID khối trăm (`_101`, `_201`, `_301`).
   - Lưu vào `01_ngan_hang_de_tho/<Mã_chương>.json` để Thầy/Cô mở `Duyet_va_tao_de.html` phê duyệt trực quan một chạm.

---

## 5. Hướng dẫn Đóng gói Xuất xưởng Môn học mới

Khi muốn bàn giao bộ công cụ khảo thí cho đồng nghiệp hoặc giáo viên môn học khác:
1. Mở terminal tại thư mục dự án và chạy:
   ```bash
   npm run package
   ```
   *(Hoặc chạy lệnh: `python3 dong_goi/scripts/dong_goi.py <Ten_Mon_Hoc>`)*.
2. Tệp nén sạch sẽ được tạo tại thư mục `dong_goi/dist/<Ten_Mon_Hoc>.zip`.
3. Giáo viên nhận tệp zip chỉ cần giải nén ra máy tính là có ngay toàn bộ phần mềm sẵn sàng làm việc!

---

## 6. Nhận thông báo phiên bản mới & Quy trình cập nhật (Bảo toàn dữ liệu 100%)

Hệ thống tích hợp sẵn cơ chế kiểm tra và thông báo phiên bản mới tự động nhằm giúp Thầy/Cô luôn được sử dụng những tính năng khảo thí tiên tiến nhất mà không lo mất dữ liệu hay gián đoạn việc giảng dạy.

### Cách nhận biết khi có bản cập nhật mới
1. **Thông báo trên ứng dụng máy tính (`Duyet_va_tao_de.html`):**
   - Khi mở ứng dụng hoặc mở thẻ **"🌐 Quản trị Cloud"**, hệ thống sẽ tự động kiểm tra phiên bản mới từ Tác giả.
   - Khi có bản mới, trên thanh công cụ Top Bar sẽ xuất hiện huy hiệu: **`🔔 Có bản cập nhật mới (v5.x)`**.
2. **Xem chi tiết bản nâng cấp:**
   - Nhấp chuột vào huy hiệu thông báo hoặc bấm nút **`🔍 Kiểm tra cập nhật ngay`** tại Tab 4 "Quản trị Cloud" để xem thông tin tính năng mới và các cải tiến.

### Quy trình 2 bước cập nhật phần mềm (Chỉ mất 30 giây — An toàn 100%)

> [!IMPORTANT]
> **Nguyên tắc bảo toàn dữ liệu:**
> Quá trình cập nhật **tuyệt đối KHÔNG làm mất** bất kỳ câu hỏi, đề thi nào trên máy tính, và **KHÔNG làm mất sổ điểm hay đổi link Web App** của sinh viên!

* **Bước 1 — Cập nhật ứng dụng trên máy tính:**
  1. Tải gói cập nhật mới (tệp `.zip`) do Tác giả cung cấp.
  2. Giải nén và chép đè vào thư mục môn học trên máy tính (hoặc nhấp đúp file `Cai_Dat_Hoac_Cap_Nhat.bat`).
  3. Mở lại tệp `06_duyet_va_tao_de/Duyet_va_tao_de.html` ➔ Toàn bộ giao diện và tính năng mới sẽ được áp dụng ngay lập tức.
* **Bước 2 — Cập nhật Thư viện trên Google Sheet:**
  1. Mở tệp Google Sheet môn học trên trình duyệt ➔ Chọn **Tiện ích mở rộng ➔ Apps Script**.
  2. Ở cột bên trái, tại mục **Thư viện (Libraries)**: Bấm vào dòng `TracNghiemCore`.
  3. Tại ô **Phiên bản (Version)**: Chọn con số phiên bản mới nhất (ví dụ chọn bản số cao nhất) ➔ Bấm **Lưu (Save)**.
  4. Ở góc trên bên phải, bấm **Triển khai (Deploy) ➔ Quản lý bản triển khai (Manage deployments)** ➔ Bấm cây bút chì ✏️ ➔ Dòng **Phiên bản (Version)** chọn **Phiên bản mới (New version)** ➔ Bấm **Triển khai (Deploy)**.
  👉 **Kết quả:** Cổng thi và làm bài của sinh viên tự động nhận giao diện và logic mới nhất, trong khi **đường link Web App gửi cho sinh viên giữ nguyên vĩnh viễn không đổi**!

