# Thư mục con: Bài tập về nhà theo tuần (Assignment Mode)

Thư mục này lưu trữ các đề bài tập rèn luyện định kỳ theo tuần dành cho sinh viên:

- **Đặc điểm:** Tương tự cấu trúc đề thi trắc nghiệm, hỗ trợ hiển thị đáp án và lời giải chi tiết khi sinh viên hoàn thành bài tập.
- **Quy chuẩn đặt tên tệp:** `BT_Tuan_<Số_tuần>.json` hoặc `BT_<Chủ_đề>.json` (ví dụ: `BT_Tuan_01.json`, `BT_Tuan_02.json`).
- **Cách sử dụng:** Đặt các tệp bài tập vào đây, sau đó mở Tab Quản trị Cloud trong `Duyet_va_tao_de.html` và bấm **"Đồng bộ toàn bộ dữ liệu"** để đẩy lên Google Drive. Sinh viên truy cập chế độ Bài tập (`?mode=assignment`) sẽ tự động thấy danh sách bài tập theo tuần để làm và điểm danh tự học.
