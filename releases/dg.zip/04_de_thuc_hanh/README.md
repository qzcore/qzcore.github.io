# Thư mục 04: Đề thực hành & Ôn tập (Practice Mode)

Thư mục này lưu trữ các bộ đề thi phục vụ cho sinh viên tự luyện tập và ôn thi trực tuyến:

- **Đặc điểm:** Tương tự cấu trúc của đề thi chính thức (`03_de_thi/`), nhưng thiết lập cờ `showExplanation: true` để cho phép sinh viên xem ngay đáp án và lời giải chi tiết sau khi nộp bài.
- **Quy chuẩn đặt tên tệp:** `TH_<Mã_chủ_đề>_<Số_thứ_tự>.json` (ví dụ: `TH_C05_01.json`).
- **Cách sử dụng:** Tải tệp lên thư mục `04_de_thuc_hanh/` trên Google Drive để kích hoạt chế độ làm bài tự luyện trên WebClient.

