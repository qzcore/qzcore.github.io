# Thư mục 02: Ngân hàng đề thi chính thức (Đã thẩm định & duyệt)

Thư mục này chứa các tệp câu hỏi chuẩn đã được giảng viên thẩm định và phê duyệt thông qua ứng dụng **`Duyet_va_tao_de.html`**:

- **Tiêu chuẩn chất lượng:** 100% câu hỏi trong thư mục này đã vượt qua 11 tiêu chí kỹ thuật (V01 – V11), không bị lỗi cú pháp KaTeX, không có phương án trùng lặp, đầy đủ lời giải sư phạm chi tiết.
- **Mục đích sử dụng:** Là nguồn dữ liệu gốc ("mỏ câu hỏi sạch") để hệ thống tự động bốc và sinh đề thi chính thức tại Tab **"📝 Tạo đề thi chính thức"**.

