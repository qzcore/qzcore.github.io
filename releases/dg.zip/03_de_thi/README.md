# Thư mục 03: Đề thi chính thức (Snapshot)

Thư mục này lưu trữ các tệp đề thi chính thức được tạo ra tự động từ ứng dụng **`Duyet_va_tao_de.html`**:

- **Quy chuẩn đặt tên tệp:** `DT_YYYYMMDD_HHMM.json` (ví dụ: `DT_20261107_1200.json`).
- **Nội dung tệp đề:** Là một bản snapshot độc lập chứa toàn bộ danh sách câu hỏi đã được trộn thứ tự và trộn phương án theo thuật toán Fisher-Yates (có mã hóa hạt giống `seed`), kèm ma trận phân bổ độ khó (60% Nhận biết, 30% Vận dụng, 10% Vận dụng cao).
- **Cách sử dụng:**
  1. **Khảo thí trực tuyến:** Kéo thả tệp JSON này lên thư mục `03_de_thi/` trên Google Drive môn học ➔ Vào Google Sheets kích hoạt đề thi.
  2. **In ấn thi trên giấy:** Dùng dữ liệu tệp này để kết xuất sang Quarto/PDF trong thư mục `05_xuat_ban_pdf/`.

