---
name: curriculum-topic-creator
description: Tự động khảo sát internet, tổng hợp nội dung môn học và thiết lập cây chuyên đề 2 cấp độ (Chương lớn ➔ Chuyên đề bài học nhỏ), tự động xuất bản tài liệu chuẩn Quarto (.qmd) vào '00_du_lieu_ra_de/' phục vụ biên soạn câu hỏi và ra đề thi. Kích hoạt khi người dùng yêu cầu tạo chuyên đề, khảo sát môn học, xây dựng khung chương trình hoặc chuẩn bị dữ liệu ra đề.
---

<!-- 
Author: T.M.Tường & Trợ lý AI Antigravity
Description: Global & Local Antigravity Skill for Automated Curriculum Research, 2-Tier Topic Architecture & Quarto Reference Generation for Academic Assessment Workspaces.
-->

# Curriculum Topic Creator (Thiết Kế Cây Chuyên Đề & Xuất Bản Dữ Liệu Ra Đề)

Skill chuyên trách hỗ trợ Giáo viên THPT và Giảng viên Đại học xây dựng khung chương trình, cây kiến thức chuẩn hóa 2 cấp độ và tự động xuất bản tài liệu tham khảo Quarto (`.qmd`) vào thư mục `00_du_lieu_ra_de/` làm cơ sở dữ liệu gốc (Single Source of Truth) cho việc biên soạn ngân hàng câu hỏi trắc nghiệm.

---

## 1. Nguyên Tắc Cốt Lõi

1. **Khảo sát Nguồn Chuẩn (Internet Fact-Checking):**
   - Luôn sử dụng công cụ tìm kiếm internet (`search_web`) để tra cứu chương trình chính thức:
     - *Bậc phổ thông:* Chương trình Giáo dục Phổ thông 2018 (GDPT 2018) của Bộ GD&ĐT, các bộ SGK hiện hành (Kết nối tri thức, Cánh Diều, Chân trời sáng tạo).
     - *Bậc Đại học:* Đề cương chi tiết học phần chuẩn, giáo trình của các trường Đại học trọng điểm.
   - Bắt buộc cập nhật danh pháp quốc tế IUPAC tiếng Anh (đối với Hóa học) và chuẩn ký hiệu khoa học mới nhất.

2. **Kiến Trúc Cây Chuyên Đề 2 Cấp Độ (2-Tier Topic Architecture):**
   Khắc phục triệt để sự nhầm lẫn giữa "Chương lớn" và "Chuyên đề bài học nhỏ":
   - **Cấp độ 1 (Level 1 - Macro / Chương lớn):** Khối kiến thức lớn của môn học (Mã: `C01`, `C02`, `C03`...). Ví dụ: *Chương 1: Cân bằng hoá học*, *Chương 2: Nitrogen và Sulfur*, *Chương 2: Tóm tắt và phân tổ dữ liệu*.
   - **Cấp độ 2 (Level 2 - Micro / Chuyên đề bài học nhỏ):** Các bài học/mô-đun kiến thức cụ thể bên trong Chương (Mã: `1.1`, `1.2`, `1.3`... hoặc `C01_CD01`, `C01_CD02`...). Mỗi chuyên đề con có mục tiêu độc lập, nội dung cốt lõi và yêu cầu cần đạt (YCCĐ) riêng biệt.

3. **Xuất Bản Trực Tiếp File Quarto (`.qmd`) vào `00_du_lieu_ra_de/`:**
   - Mọi chuyên đề sau khi tổng hợp BẮT BUỘC phải được lưu trữ dưới dạng tệp Quarto `.qmd` tại:
     `00_du_lieu_ra_de/tai_lieu_<ma_chuong>_<ten_chuong_khong_dau>.qmd`
     *(Ví dụ: `00_du_lieu_ra_de/tai_lieu_C01_ChiTieuVaDoLuong.qmd` hoặc `00_du_lieu_ra_de/tai_lieu_C01_CanBangHoaHoc.qmd`)*.
   - Tệp `.qmd` được thiết kế chuẩn mực: có header YAML sẵn sàng biên dịch sang PDF qua XeLaTeX, hỗ trợ công thức toán học (`amsmath, amssymb`), gói hóa học `mhchem` (`\usepackage[version=4]{mhchem}`), bảng biểu `booktabs, tabularx`.

4. **Sẵn Sàng Tiếp Ứng Ra Đề (Seamless Handshake với `exam-creator`):**
   - Tài liệu `.qmd` trong `00_du_lieu_ra_de/` là nguồn dữ liệu gốc (Single Source of Truth) để skill tạo đề đọc và bám sát khi sinh câu hỏi trắc nghiệm đạt 11 tiêu chuẩn kỹ thuật (V01 - V11).
   - Tuyệt đối không sinh câu hỏi trôi nổi mà không có căn cứ từ tệp tài liệu `.qmd`.

---

## 2. Quy Trình Vận Hành 4 Bước

```mermaid
flowchart TD
    A["Nhận Tên Môn học & Cấp học<br>(vd: Hóa học 11 GDPT 2018 / PTDLKD UFM)"] --> B["Bước 1: Khảo sát Internet<br>(search_web tra cứu SGK & Chương trình)"]
    B --> C["Bước 2: Xây dựng Cây 2 Cấp độ<br>(Level 1: Chương ➔ Level 2: Chuyên đề con)"]
    C --> D["Bước 3: Xuất bản tệp .qmd<br>(Ghi vào 00_du_lieu_ra_de/)"]
    D --> E["Bước 4: Bàn giao sang Skill Tạo Đề<br>(Sẵn sàng cho exam-creator đọc và sinh câu hỏi)"]
```

### Bước 1: Khảo Sát & Tổng Hợp Kiến Thức Từ Internet
- Sử dụng `search_web` tra cứu theo các từ khóa:
  - `"[Tên môn học] chương trình GDPT 2018 yêu cầu cần đạt"`
  - `"[Tên môn học] đề cương chi tiết học phần"`
  - `"[Tên chuyên đề] lý thuyết trọng tâm bài tập công thức"`
- Trích xuất:
  - Khung phân phối thời lượng và thứ tự các chương.
  - Các khái niệm định nghĩa chuẩn mực, định luật, nguyên lý.
  - Danh mục các dạng bài tập định tính và định lượng điển hình.
  - Các bẫy sai lầm kinh điển mà học sinh/sinh viên hay mắc phải.

### Bước 2: Thiết Kế Cây Chuyên Đề 2 Cấp Độ
Thiết lập bảng ma trận phân phối chuẩn:
- **Cấp độ 1:**
  - Mã định danh: `C01`, `C02`, `C03`...
  - Tên chương, mục tiêu tổng quan.
- **Cấp độ 2:**
  - Chia mỗi chương thành **3 đến 5 chuyên đề con** mạch lạc (`1.1`, `1.2`, `1.3`... hoặc `CĐ1`, `CĐ2`, `CĐ3`...).
  - Mỗi chuyên đề xác định rõ:
    - **Tên chuyên đề con.**
    - **Phạm vi kiến thức trọng tâm.**
    - **Yêu cầu cần đạt (YCCĐ):** Người học nhận biết được gì, hiểu được gì, vận dụng và tính toán được gì.

### Bước 3: Xuất Bản Tệp Quarto `.qmd` vào `00_du_lieu_ra_de/`
Tự động khởi tạo hoặc cập nhật tệp `.qmd` tương ứng trong `00_du_lieu_ra_de/tai_lieu_<Mã_chương>_<Tên_chương_không_dấu>.qmd` theo đúng cấu trúc mẫu ở Mục 3 dưới đây.

### Bước 4: Chuẩn Bị Bước Kế Tiếp Cho Khâu Ra Đề (Handshake)
- Kiểm tra tệp JSON tương ứng trong `01_ngan_hang_de_tho/<Mã_Chương>.json`. Cập nhật phần `lesson` (`summary` và `keyPoints`) khớp với tài liệu `.qmd` vừa tạo.
- Báo cáo rõ ràng cho Giáo viên: Cây 2 cấp độ đã được thiết lập, tài liệu `.qmd` đã sẵn sàng trong `00_du_lieu_ra_de/`. Hướng dẫn Giáo viên ra lệnh tạo câu hỏi theo từng chuyên đề con cụ thể (ví dụ: *"soạn 15 câu cho CĐ1 của Chương 2"*).

---

## 3. Mẫu Cấu Trúc Tệp Quarto Chuẩn (`00_du_lieu_ra_de/*.qmd`)

Mỗi tệp `.qmd` xuất bản vào `00_du_lieu_ra_de/` phải tuân thủ nghiêm ngặt cấu trúc sau:

```markdown
---
title: "Tài liệu chương [Tên Chương] ([Môn học - Cấp học])"
subtitle: "Dữ liệu kiến thức chuẩn GDPT 2018 / Đề cương Đại học phục vụ biên soạn ngân hàng câu hỏi và ra đề thi"
author: "T.M.Tường & Trợ lý AI Antigravity"
date: today
date-format: "DD/MM/YYYY"
format:
  pdf:
    documentclass: article
    papersize: a4
    geometry:
      - top=20mm
      - bottom=20mm
      - left=20mm
      - right=20mm
    fontsize: 11pt
    pdf-engine: xelatex
    include-in-header:
      text: |
        \usepackage{fontspec}
        \usepackage[version=4]{mhchem}
        \usepackage{amsmath,amssymb}
        \usepackage{booktabs}
        \usepackage{tabularx}
---

## Tổng quan chương

Mô tả ngắn gọn phạm vi kiến thức, vị trí của chương trong chương trình môn học và vai trò ứng dụng thực tiễn.

---

## 1. Khung các chuyên đề trọng tâm (Cây 2 cấp độ)

| Chuyên đề con | Phạm vi kiến thức trọng tâm | Yêu cầu cần đạt (YCCĐ) |
|:---|:---|:---|
| **CĐ1: [Tên CĐ1]** | - Nội dung 1.<br>- Nội dung 2. | Nhận biết, giải thích và viết được... |
| **CĐ2: [Tên CĐ2]** | - Nội dung 1.<br>- Nội dung 2. | Tính toán và vận dụng được... |
| **CĐ3: [Tên CĐ3]** | - Nội dung 1.<br>- Nội dung 2. | Phân tích và giải quyết tình huống... |

: Danh mục các chuyên đề trọng tâm Chương [Số] {#tbl-chuyen-de}

---

## 2. Kiến thức cốt lõi & Công thức / Phương trình quan trọng

### 2.1. Chuyên đề 1: [Tên CĐ1]
- **Khái niệm & Định luật:** ...
- **Công thức / Phương trình:** Sử dụng KaTeX `$ ... $` hoặc `$$ ... $$` chuẩn xác.
- **Hiện tượng thí nghiệm / Thực tiễn:** ...

### 2.2. Chuyên đề 2: [Tên CĐ2]
...

---

## 3. Các dạng bài tập trọng tâm & Bẫy tư duy kinh điển

1. **Dạng 1: [Tên dạng bài tập]**
   - Phương pháp giải chuẩn: ...
   - Bẫy học sinh hay mắc phải: ...
2. **Dạng 2: [Tên dạng bài tập]**
   - Phương pháp giải chuẩn: ...
   - Bẫy học sinh hay mắc phải: ...

---

## 4. Định hướng ma trận nhận thức cho ngân hàng câu hỏi

- **Nhận biết & Thông hiểu (60%):** Các câu hỏi lý thuyết, danh pháp, hiện tượng, công thức trực tiếp.
- **Vận dụng (30%):** Bài toán tính toán 1-2 bước, chuyển dịch cân bằng, xác định nồng độ/thể tích/chỉ số/ước lượng.
- **Vận dụng cao (10%):** Bài toán kết hợp đa chuyên đề, biện luận dữ liệu thực nghiệm, phân tích mô hình kinh tế/thực tế.
```

---

## 4. Kịch Bản Tương Tác Cùng Giáo Viên

Khi người dùng đưa ra yêu cầu:
> *"Hãy xây dựng các chuyên đề cho môn Vật lý 11 (hoặc Hóa học 11, Kinh tế vi mô, Phân tích dữ liệu kinh doanh...)"*

1. **Thực thi:**
   - Sử dụng `search_web` tra cứu chuẩn xác chương trình hiện hành.
   - Trình bày tóm tắt Cây chuyên đề 2 cấp độ trực tiếp trong câu trả lời để Giáo viên duyệt nhanh.
   - Tự động ghi tệp `.qmd` vào `00_du_lieu_ra_de/tai_lieu_<Mã_chương>_<Tên_chương>.qmd`.
2. **Báo cáo hoàn thành:**
   > *"✅ Tôi đã khảo sát internet và xây dựng xong Cây chuyên đề 2 cấp độ cho môn `[Tên môn]`.  
   > 📄 Toàn bộ nội dung lý thuyết, công thức và dạng bài tập đã được xuất bản vào tệp: `[00_du_lieu_ra_de/tai_lieu_...qmd]`.  
   > 🎯 Thầy/cô có thể xem lại tệp trên hoặc yêu cầu tôi bắt đầu biên soạn ngân hàng câu hỏi cho bất kỳ Chuyên đề con nào (ví dụ: 'soạn 15 câu cho CĐ1') nhé!"*
