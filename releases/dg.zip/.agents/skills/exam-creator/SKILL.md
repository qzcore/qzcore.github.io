---
name: exam-creator
description: Generates high-quality, self-contained multiple-choice questions (MCQs) for any subject (PTDLKD, Chemistry, Physics, Economics, Mathematics, etc.), supporting 2-tier topic architecture (Macro chapters & Micro subTopics), 60/30/10 difficulty matrix, absolute data self-containment, 4-decimal rounding (2 decimals for %), standardized critical value notations (z_{alpha/2}, z_alpha without numeric subscripts), manual table lookup from reference tables, KaTeX math formulas, plausible distractors, parallel explanations[] without letter labels, and structured JSON output with hundred-block IDs for the exam review and micro-learning pipeline.
---

<!--
Author: T.M.Tường & Trợ lý AI Antigravity
Description: Global & Local Antigravity Skill for Creating Pedagogical MCQs across Academic Disciplines with 2-Tier Topic Architecture, KaTeX, Standalone Context & Structured Review Pipeline.
-->

# Academic Exam Creator (Biên Soạn Ngân Hàng Câu Hỏi Trắc Nghiệm Chuẩn Hóa)

Skill chuyên trách hỗ trợ biên soạn ngân hàng câu hỏi trắc nghiệm khách quan 4 lựa chọn (A, B, C, D) chất lượng cao cho mọi học phần đại học và môn học phổ thông (Toán, Vật lý, Hóa học, Sinh học, Tin học, Kinh tế, Ngoại ngữ...), bám sát tệp tài liệu Quarto (`.qmd`) do skill `curriculum-topic-creator` cung cấp và tuân thủ 11 tiêu chuẩn kỹ thuật (V01 – V11). Đồng thời tích hợp module chuyên sâu cho môn **Phân tích dữ liệu kinh doanh (PTDLKD - UFM)**.

---

## 1. Nguyên tắc độc lập dữ liệu tuyệt đối (Absolute Data Self-Containment)

Mọi câu hỏi do Skill tạo ra BẮT BUỘC phải là **một thực thể độc lập hoàn toàn (Self-contained / Standalone Question)**:

1. **Đầy đủ dữ liệu tự thân:** Mỗi câu hỏi phải chứa trọn vẹn 100% ngữ cảnh, tình huống, bảng số liệu hoặc các tham số cần thiết ($n, \bar{x}, s, \sum p_1 q_1, \alpha, \dots$) để thí sinh giải quyết được câu hỏi đó mà không cần bất kỳ thông tin nào từ câu hỏi khác.
2. **Nghiêm cấm tuyệt đối các câu hỏi phụ thuộc bắc cầu:**
   - ❌ **CẤM** các câu dẫn dạng: *"Dựa vào số liệu ở câu trên..."*, *"Với bảng phân tổ ở Câu 1, hãy tính..."*, *"Tiếp tục câu hỏi trước..."*, *"Từ kết quả trung bình vừa tính được, hãy tìm phương sai..."*.
   - ❌ **CẤM** liên kết dữ liệu chuỗi giữa các câu hỏi liền kề.
3. **Lý do kỹ thuật và sư phạm bắt buộc:**
   - **Xáo trộn ngẫu nhiên câu hỏi (`shuffleQuestions`):** Khi thi thật hay thực hành, hệ thống luôn xáo trộn ngẫu nhiên thứ tự câu hỏi theo từng sinh viên. Nếu câu sau dựa vào câu trước, đề thi sẽ bị gãy vụn ngữ cảnh và sinh viên không thể làm bài.
   - **Bốc đề ngẫu nhiên theo ma trận:** Khi tạo đề thi, hệ thống bốc câu hỏi ngẫu nhiên từ ngân hàng; hai câu kế tiếp nhau trong ngân hàng sẽ không chắc chắn cùng xuất hiện trong một đề thi.
   - **Thi chùm nhiều mã đề:** Mỗi mã đề con nhận một tập câu hỏi khác nhau.
4. **Quy tắc xử lý bài toán chung ngữ cảnh:**
   - Nếu muốn khai thác nhiều khía cạnh từ cùng một bộ số liệu (ví dụ bảng dữ liệu trong Đề số 01 UFM), **bắt buộc phải lặp lại đầy đủ bảng số liệu đó trong từng câu hỏi**.
   - Đối với các câu hỏi kiểm tra bước sau (như tính phương sai hay kiểm định), phải **cung cấp sẵn các giá trị trung gian cần thiết ngay trong đề bài** (ví dụ: *"Cho bảng phân tổ sau... Biết rằng số bình quân đã tính được là $\bar{x} = 22,4500$, phương sai mẫu hiệu chỉnh $s^2$ là:"*).

---

## 2. Quy chuẩn tính toán, làm tròn số và tra bảng thống kê bằng tay

Nhằm chuẩn hóa việc dạy, học và khảo thí bám sát kỳ thi tập trung của Trường Đại học Tài chính - Marketing (UFM), Skill BẮT BUỘC tuân thủ các quy chuẩn sau:

### 2.1. Quy tắc làm tròn số 4 chữ số thập phân & Định dạng phần trăm (%)
1. **Mọi phép tính số học (số thập phân thông thường):**
   - Cả các bước tính toán trung gian lẫn kết quả cuối cùng đều được làm tròn đến **4 chữ số thập phân** (ví dụ: $\bar{x} = 22,3456$; $s = 1,2345$; $s^2 = 1,5240$; $z_{qs} = 1,9876$; $t_{qs} = 2,1542$).
2. **Số ở dạng tỷ lệ / phần trăm (%):**
   - Trong quá trình tính toán (dưới dạng số thập phân): Giữ đúng **4 chữ số thập phân** (ví dụ: $p = 0,1234$; $\alpha = 0,0500$; $SE = 0,0145$).
   - Khi hiển thị / trình bày phương án có gắn ký hiệu `%`: Làm tròn còn **2 chữ số lẻ sau dấu phẩy** (ví dụ: $0,1234 \to 12,34\%$; $0,0500 \to 5,00\%$; $0,9500 \to 95,00\%$).

### 2.2. Quy ước ký hiệu giá trị tới hạn ($z$, $t$, $\chi^2$) trong bài toán ước lượng và kiểm định
1. **Đối với phân phối chuẩn Gauss / Laplace ($z$):**
   - **Bài toán 2 phía (Ước lượng đối xứng, Kiểm định 2 phía):** Ký hiệu là $z_{\alpha/2}$.
   - **Bài toán 1 phía (Ước lượng chặn trên/dưới, Kiểm định 1 phía):** Ký hiệu là $z_\alpha$.
2. **Đối với phân phối Student ($t$):**
   - **Bài toán 2 phía (Ước lượng đối xứng, Kiểm định 2 phía):** Ký hiệu là $t_{\alpha/2}^{(n-1)}$ (hoặc $t_{\alpha/2}$). Giữ nguyên chữ $\alpha$, tuyệt đối không thay số vào chỉ số chân (không viết $t_{0,05}^{(n-1)}$ hay $t_{0,025}^{(n-1)}$). Tra bảng Student UFM ở dòng bậc tự do $n - 1$, cột $a = \alpha$.
   - **Bài toán 1 phía (Ước lượng chặn trên/dưới, Kiểm định 1 phía):** Ký hiệu là $t_\alpha^{(n-1)}$ (hoặc $t_\alpha$). Giữ nguyên chữ $\alpha$, tuyệt đối không thay số vào chỉ số chân (không viết $t_{0,05}^{(n-1)}$ hay $t_{0,10}^{(n-1)}$). Tra bảng Student UFM ở dòng bậc tự do $n - 1$, cột $a = 2\alpha$.
3. **Đối với phân phối Chi-bình phương ($\chi^2$):**
   - **Bài toán 2 phía (Ước lượng phương sai 2 phía):** Ký hiệu là ${\chi^2_{\alpha/2}}^{(n-1)}$ và ${\chi^2_{1-\alpha/2}}^{(n-1)}$ (bắt buộc bọc nhóm `{\chi^2_{...}}^{(...)}` để tránh lỗi *Double superscript* trong LaTeX/KaTeX).
   - **Bài toán 1 phía (Ước lượng phương sai chặn trên/dưới):** Ký hiệu là ${\chi^2_\alpha}^{(n-1)}$ hoặc ${\chi^2_{1-\alpha}}^{(n-1)}$.
4. **Quy tắc cốt lõi "không tính ra số, chỉ ghi $\alpha$":**
   - Trong đề thi, câu hỏi trắc nghiệm, công thức toán, các bước xây dựng khoảng ước lượng hoặc miền bác bỏ $W_\alpha$: Ký hiệu giá trị tới hạn luôn giữ nguyên chữ $\alpha$ ở dạng đại số tổng quát ($z_{\alpha/2}$, $z_\alpha$, $t_{\alpha/2}^{(n-1)}$, $t_\alpha^{(n-1)}$, ${\chi^2_{\alpha/2}}^{(n-1)}$, ${\chi^2_{1-\alpha/2}}^{(n-1)}$). **Tuyệt đối không thay số mức ý nghĩa vào chỉ số chân** (nghĩa là ghi rõ $z_{\alpha/2}$, $z_\alpha$, $t_{\alpha/2}^{(n-1)}$, $t_\alpha^{(n-1)}$, **không** ghi kiểu $z_{0,025}$, $z_{0,05}$, $t_{0,05}^{(19)}$).
5. **Bắt buộc sinh viên tự tra bảng bằng tay (Tuyệt đối không cho sẵn giá trị tra bảng trong đề):**
   - Trong phần đề dẫn của câu hỏi trắc nghiệm, **tuyệt đối không kèm dòng ghi chú cho sẵn giá trị phân vị** (ví dụ: ❌ KHÔNG ghi *"Cho biết: $z_{0,025} = 1,96$"* hay *"Cho biết $t_{0,05}^{(20)} = 1,725$"*).
   - Đề thi chỉ cung cấp mức ý nghĩa $\alpha$ hoặc độ tin cậy $1 - \alpha$, sinh viên bắt buộc phải tự cầm bảng tra bằng tay để dò tìm giá trị tới hạn.

### 2.3. Quy tắc nội suy: Lấy trung bình cộng của 2 số gần đúng nhất
Khi tra bảng mà giá trị cần tìm **không có con số chính xác tuyệt đối** trong bảng tra:
- Xác định **2 giá trị kẹp sát gần đúng nhất** (một giá trị cận dưới $v_1$ và một giá trị cận trên $v_2$).
- Lấy **trung bình cộng** của 2 giá trị đó:
  $$\text{Giá trị chọn} = \frac{v_1 + v_2}{2}$$
- **Ví dụ điển hình khi tra ngược bảng Laplace $\varphi(x) = P(0 \le X \le x)$:**
  - Khi kiểm định 1 phía mức ý nghĩa $\alpha = 0,05$ hoặc ước lượng với độ tin cậy $90\%$ ($1 - \alpha = 0,90$): Ta cần tìm $z$ sao cho $\varphi(z) = 0,4500$.
  - Tra bảng Laplace:
    - Tại $z = 1,64 \Rightarrow \varphi(1,64) = 0,4495$
    - Tại $z = 1,65 \Rightarrow \varphi(1,65) = 0,4505$
  - Không có số $0,4500$ chính xác, hai giá trị gần nhất là $1,64$ và $1,65$.
  - Áp dụng quy tắc trung bình cộng: $z = \frac{1,64 + 1,65}{2} = 1,645$.

### 2.4. Căn cứ tra bảng duy nhất (Bảng tra UFM)
Toàn bộ việc tính toán đáp án đúng và xây dựng lời giải chi tiết phải đối chiếu chính xác với tài liệu:
[`references/bang_tra_thong_ke_ufm.md`](references/bang_tra_thong_ke_ufm.md)
- Bảng 1: Phân phối Gauss (Hàm Laplace $\varphi(x)$, tích phân từ $0$ đến $x$).
- Bảng 2: Phân phối Student ($T \sim St(n)$).
- Bảng 3: Phân phối Chi-bình phương ($X \sim \chi^2(n)$).
- Bảng 4 & 5: Phân phối Fisher ($F_{0,05}(n, m)$ và $F_{0,01}(n, m)$).

---

## 3. Nguyên tắc phân bổ độ khó (60% - 30% - 10%)

Mọi bộ đề thi hoặc ngân hàng câu hỏi do Skill tạo ra đều BẮT BUỘC tuân thủ đúng tỷ lệ nhận thức:

| Nhóm nhận thức | Tỷ lệ | Định hướng nội dung & Yêu cầu sư phạm môn PTDLKD |
| :--- | :---: | :--- |
| **Nhận biết & Thông hiểu** (`Nhan_biet_Thong_hieu`) | **60%** | - Nhận diện khái niệm: tổng thể, mẫu, đơn vị quan sát, biến ngẫu nhiên, chỉ tiêu thống kê.<br>- **Phân loại thang đo & dữ liệu:** Thang đo định danh (Nominal), thứ bậc (Ordinal), khoảng (Interval), tỷ lệ (Ratio); dữ liệu định tính/định lượng, sơ cấp/thứ cấp.<br>- **Lý thuyết phân tổ & mô tả:** Công thức Sturgess xác định số tổ, ý nghĩa của số bình quân ($\bar{x}$), trung vị ($M_e$), mốt ($M_o$), phương sai mẫu ($s^2$), độ lệch chuẩn ($s$), hệ số biến thiên ($CV$).<br>- **Chỉ số kinh tế:** Bản chất và ý nghĩa kinh tế của chỉ số giá/khối lượng Laspeyres, Paasche, Fisher; phân biệt dãy số thời kỳ (cộng dồn được) và thời điểm (không cộng dồn được).<br>- **Lý thuyết mẫu & kiểm định:** Định lý giới hạn trung tâm (CLT); khái niệm giả thuyết $H_0, H_1$, mức ý nghĩa $\alpha$, sai lầm loại 1 ($\alpha$) và sai lầm loại 2 ($\beta$); ý nghĩa trị số $p$-value. |
| **Vận dụng** (`Van_dung`) | **30%** | - **Thống kê mô tả từ bảng phân tổ:** Tính mật độ phân phối ($d_i = m_i / h_i$) với tổ không đều; tính trung bình mẫu $\bar{x}$, phương sai mẫu hiệu chỉnh $s^2$, xác định mốt $M_o$ và trung vị $M_e$ qua công thức nội suy.<br>- **Chỉ số & biến động kinh tế:** Tính chỉ số giá $I_p$, chỉ số khối lượng $I_q$, tính biến động chi phí tuyệt đối do giá $\Delta C_p$ và do khối lượng $\Delta C_q$.<br>- **Dãy số thời gian & dự báo:** Tính lượng tăng/giảm tuyệt đối (liên hoàn, định gốc, bình quân), tốc độ phát triển liên hoàn/định gốc, dự báo bằng ngoại suy xu thế hoặc lượng tăng giảm bình quân.<br>- **Ước lượng tham số:** Tính khoảng tin cậy cho trung bình tổng thể $\mu$ (phân phối $Z$ khi $\sigma$ đã biết, phân phối $t$-Student khi $\sigma$ chưa biết), ước lượng tỷ lệ $p$, xác định cỡ mẫu tối thiểu $n$.<br>- **Kiểm định giả thuyết:** Tính giá trị tiêu chuẩn kiểm định $Z_{qs}$ hoặc $t_{qs}$, đối chiếu với giá trị tới hạn để đưa ra kết luận chấp nhận hay bác bỏ $H_0$. |
| **Vận dụng cao** (`Van_dung_cao`) | **10%** | - **Phân tích hình dáng phân phối:** Biện luận mối quan hệ $\bar{x} < M_e < M_o$ (lệch trái / Skewed Left) hoặc $M_o < M_e < \bar{x}$ (lệch phải / Skewed Right) gắn với phân tích thu nhập hoặc năng suất lao động.<br>- **Hệ thống chỉ số nhân tố:** Phân tích biến động tổng hợp đa nhân tố và kiểm tra phương trình cân bằng tuyệt đối $\Delta C = \Delta C_p + \Delta C_q$.<br>- **Dự báo chuỗi thời gian nâng cao:** Dự báo có yếu tố thời vụ kết hợp mô hình nhân (Multiplicative Model) hoặc san bằng mũ.<br>- **Khai thác output R trong kinh doanh:** Đọc kết quả chạy R (`t.test`, `prop.test`, `aov`), phân tích trị số $p$-value và đưa ra quyết định kinh doanh / quản trị chính xác. |

---

## 4. Kỹ thuật thiết kế phương án gây nhiễu (Plausible Distractor Engineering)

Skill KHÔNG ĐƯỢC bịa đáp án ngẫu nhiên hoặc các phương án vô nghĩa. Ba phương án sai (distractors) bắt buộc phải phản ánh **chính xác các bẫy tư duy kinh điển của sinh viên ngành Kinh tế**:

1. **Bẫy phân tổ & thống kê mô tả (Chương 2):**
   - *Lỗi Sturgess:* Lấy giá trị $k = 1 + 3,322 \log_{10}(n)$ làm tròn xuống thay vì làm tròn lên để bao phủ toàn bộ khoảng biến thiên $R$.
   - *Lỗi tổ không đều:* Tính tần số $m_i$ trực tiếp để tìm mốt mà quên quy đổi về mật độ phân phối $d_i = m_i / h_i$.
   - *Lỗi phương sai mẫu:* Chia cho $n$ thay vì $n - 1$ (quên bậc tự do hiệu chỉnh).
   - *Lỗi khoảng cách:* Nhầm lẫn giữa khoảng cách tổ $h$ với khoảng biến thiên $R = x_{max} - x_{min}$.
2. **Bẫy chỉ số kinh tế (Chương 3):**
   - *Lỗi quyền số:* Nhầm quyền số kỳ gốc $q_0$ (Laspeyres) sang kỳ báo cáo $q_1$ (Paasche).
   - *Lỗi tổng tích:* Lấy tổng giá chia tổng giá rồi nhân tổng lượng thay vì tính tổng các tích $\sum p_1 q_1 / \sum p_0 q_1$.
   - *Lỗi dấu biến động:* Quên dấu âm/dương khi phân tích biến động chi phí tuyệt đối $\Delta C$.
3. **Bẫy dãy số thời gian (Chương 4):**
   - *Lỗi kỳ gốc/liên hoàn:* Nhầm công thức tốc độ phát triển liên hoàn ($t_i = y_i / y_{i-1}$) với định gốc ($T_i = y_i / y_1$).
   - *Lỗi căn bậc:* Khi tính tốc độ phát triển bình quân $\bar{t} = \sqrt[n-1]{y_n / y_1}$, lấy căn bậc $n$ thay vì $n - 1$.
   - *Lỗi cộng dồn dãy số thời điểm:* Lấy tổng cơ học các mức độ của dãy số thời điểm tồn kho thay vì dùng công thức bình quân số học hoặc bình quân theo khoảng thời gian.
4. **Bẫy ước lượng tham số (Chương 5):**
   - *Lỗi sai số chuẩn:* Quên căn bậc hai của cỡ mẫu ($\sqrt{n}$) trong mẫu số của sai số chuẩn $SE = s / \sqrt{n}$.
   - *Lỗi tra bảng phân vị:* Dùng phân phối chuẩn $Z$ khi mẫu nhỏ ($n < 30$) và $\sigma$ chưa biết (đáng lẽ phải dùng phân phối Student $t$).
   - *Lỗi mức ý nghĩa khi tra bảng:* Lấy phân vị 1 phía $\alpha$ thay vì 2 phía $\alpha/2$ cho khoảng tin cậy đối xứng (ví dụ độ tin cậy $95\%$ đáng lẽ lấy $1,96$ lại lấy $1,645$).
   - *Lỗi làm tròn cỡ mẫu:* Làm tròn xuống thay vì luôn làm tròn lên số nguyên kế tiếp khi tính cỡ mẫu tối thiểu $n$.
   - *Lỗi không lấy trung bình khi tra bảng:* Cần giá trị $\varphi(z) = 0,4500$, sinh viên lấy lệch về $1,64$ hoặc $1,65$ thay vì lấy đúng trung bình $1,645$.
5. **Bẫy kiểm định giả thuyết (Chương 6):**
   - *Lỗi đặt giả thuyết:* Đặt dấu bất đẳng thức ($>, <$) vào giả thuyết $H_0$ thay vì giả thuyết đối $H_1$.
   - *Lỗi kiểm định 1 phía vs 2 phía:* Sử dụng giá trị tới hạn 2 phía cho bài toán khẳng định 1 phía (ví dụ "tăng lên", "nhiều hơn").
   - *Lỗi diễn giải $p$-value:* Kết luận ngược khi $p$-value $< \alpha$ (đúng ra phải bác bỏ $H_0$).
   - *Lỗi phân biệt sai lầm:* Nhầm lẫn giữa sai lầm loại 1 (bác bỏ $H_0$ khi $H_0$ đúng) và sai lầm loại 2 (chấp nhận $H_0$ khi $H_0$ sai).
   - *Lỗi bậc tự do bảng Student:* Tra ở dòng $n$ thay vì bậc tự do hiệu chỉnh $n - 1$.

---

## 5. Quy chuẩn định dạng công thức Toán học (KaTeX) & An toàn ghi tệp

1. **Toán nội dòng (Inline Math):** Sử dụng cặp dấu `$...$` (ví dụ: `$\bar{x} = 25,4000$`, `$s^2 = 4,8200$`, `$I_p^L = 105,20\%$`, `$t_{0,025}^{(15)} = 2,1310$`).
2. **Toán khối hiển thị (Display Math):** Sử dụng cặp dấu `$$...$$` cho các công thức tính toán nhiều bước hoặc hệ thống chỉ số:
   ```latex
   $$I_{pq} = I_p \times I_q \iff \frac{\sum p_1 q_1}{\sum p_0 q_0} = \frac{\sum p_1 q_1}{\sum p_0 q_1} \times \frac{\sum p_0 q_1}{\sum p_0 q_0}$$
   ```
3. **Quy tắc an toàn ghi tệp (Chống lỗi mất biến toán học do Shell Bash):**
   - Tuyệt đối KHÔNG sử dụng `python3 -c "..."` (ngoặc kép trong shell) để ghi JSON có chứa `$`, vì bash sẽ mở rộng các ký hiệu `$A, $B, $m, $n, $Z, $p...` thành chuỗi rỗng.
   - BẮT BUỘC sử dụng công cụ `write_file` của Agent hoặc `cat << 'EOF' > file.json` (Here-doc nháy đơn `'EOF'`) để bảo toàn $100\%$ công thức và ký hiệu toán học.
   - Luôn kiểm tra tính cân bằng của dấu `$` trước khi hoàn tất (`count("$") % 2 == 0`).
4. **Ký hiệu thống kê chuẩn hóa:**
   - Số bình quân: `$\bar{x}$`, `$\mu$`
   - Phương sai: `$s^2$`, `$\sigma^2$`
   - Độ lệch chuẩn: `$s$`, `$\sigma$`
   - Mốt và Trung vị: `$M_o$`, `$M_e$`
   - Giá trị kiểm định: `$Z_{qs}$`, `$t_{qs}$`, `$F_{qs}$`, `$p$-value`
   - Giá trị tới hạn: `$z_{\alpha/2}$` (bài toán 2 phía), `$z_\alpha$` (bài toán 1 phía) — **không thay số vào chân ký hiệu**.

---

## 6. Cấu trúc dữ liệu đầu ra JSON (Schema v5.0 Bắt Buộc - Hỗ Trợ Micro-learning)

Mỗi chủ đề câu hỏi được đóng gói vào một tệp JSON hoàn chỉnh lưu tại:
`De_thi/01_PTDLKD/01_ngan_hang_de_tho/<MÃ_CHỦ_ĐỀ>.json`

Mỗi câu hỏi BẮT BUỘC tuân thủ định dạng v5.0:
- `subTopic`: Tên chuyên đề bài học nhỏ (ví dụ `"2.1 Thu thập, phân tổ và mật độ phân phối"`). Bắt buộc để phục vụ Micro-learning và lọc giao bài tập tuần.
- `correct`: Số nguyên 0-based (`0, 1, 2, 3`) đại diện cho vị trí đúng trong `options`.
- `explanations`: Mảng 4 phần tử song song với `options`. Mỗi phần tử ngắn gọn từ 1–3 câu, bắt đầu bằng `✅` nếu đúng và `❌` nếu sai. **TUYỆT ĐỐI KHÔNG dùng ký hiệu A/B/C/D trong nội dung giải thích.**

```json
{
  "schemaVersion": "1.0",
  "topicId": "C02_PhanToVaThongKeMoTa",
  "topicName": "Chương 2: Tóm tắt, phân tổ và thống kê mô tả dữ liệu",
  "subject": "PTDLKD",
  "order": 2,
  "description": "Lý thuyết phân tổ, mật độ phân phối, các đặc trưng đo lường độ tập trung và độ phân tán.",
  "lesson": {
    "summary": "Tóm tắt công thức Sturgess $k = 1 + 3,322 \\log_{10}(n)$, mật độ phân phối $d_i = m_i / h_i$, số bình quân $\\bar{x}$, phương sai mẫu hiệu chỉnh $s^2$, mốt $M_o$ và trung vị $M_e$.",
    "keyPoints": [
      "Với tổ không đều, mốt nằm ở tổ có mật độ phân phối $d_i$ lớn nhất.",
      "Phương sai mẫu hiệu chỉnh luôn chia cho $n - 1$ thay vì $n$.",
      "Phân phối lệch trái: $\\bar{x} < M_e < M_o$; phân phối lệch phải: $M_o < M_e < \\bar{x}$."
    ]
  },
  "questions": [
    {
      "id": "PTDLKD_C02_101",
      "subject": "PTDLKD",
      "subTopic": "2.1 Thu thập, phân tổ và mật độ phân phối",
      "type": "mcq_single",
      "level": "Nhan_biet_Thong_hieu",
      "score": 0.5,
      "question": "Một cuộc khảo sát thu thập thời gian giao hàng (phút) của $n = 50$ đơn vị. Khoảng biến thiên ghi nhận được là $R = 30,6000$ phút. Áp dụng công thức Sturgess, số tổ $k$ và khoảng cách tổ đều $h$ là:",
      "options": [
        { "id": "A", "text": "$k = 7$ tổ và $h \\approx 4,3714$ phút/tổ" },
        { "id": "B", "text": "$k = 6$ tổ và $h \\approx 5,1000$ phút/tổ" },
        { "id": "C", "text": "$k = 8$ tổ và $h \\approx 3,8250$ phút/tổ" },
        { "id": "D", "text": "$k = 7$ tổ và $h = 30,6000$ phút/tổ" }
      ],
      "correct": 0,
      "explanations": [
        "✅ Đúng. Sturgess: $k = 1 + 3,322 \\log_{10}(50) \\approx 6,6438$ làm tròn lên thành $k = 7$ tổ. Khoảng cách tổ $h = R / k = 30,6000 / 7 \\approx 4,3714$ phút.",
        "❌ Sai. Bẫy làm tròn xuống: $6,6438$ bị làm tròn xuống thành 6 dẫn đến $h = 30,6000 / 6 = 5,1000$. Quy tắc Sturgess yêu cầu làm tròn lên để bao phủ toàn bộ dữ liệu.",
        "❌ Sai. Chọn $k = 8$ tổ là quá nhiều so với quy mô mẫu $n = 50$, làm giảm tính đại diện của từng tổ.",
        "❌ Sai. Nhầm khoảng cách tổ $h$ với khoảng biến thiên toàn phần $R = 30,6000$ mà quên chia cho số tổ $k$."
      ],
      "tags": ["sturgess", "phan_to", "khoang_cach_to"]
    }
  ]
}
```

---

## 7. Cây Chuyên Đề 2 Cấp Độ & Dãy ID Khối Trăm Chuẩn Môn PTDLKD

Hệ thống phân cấp theo mô hình 2 tầng (Macro Chương ➔ Micro Chủ đề con `subTopic`). Mỗi chủ đề con được phân bổ một **khối trăm riêng biệt** trong mã `id` (`_101`..`_199`, `_201`..`_299`, `_301`..`_399`) để vừa nhìn là biết thuộc bài nào và chừa chỗ trống mở rộng sau này:

1. **`C01_ChiTieuVaDoLuong` — Chương 1: Chỉ tiêu và phương pháp đo lường trong thống kê:**
   - **`1.1 Tổng thể, mẫu và đơn vị quan sát`**
     - Dãy ID: `PTDLKD_C01_101` $\rightarrow$ `PTDLKD_C01_199`
     - Trọng tâm: Tổng thể bộc lộ/tiềm ẩn, mẫu đại diện, đơn vị điều tra, tiêu thức thống kê (thay đổi/không thay đổi, số lượng/thuộc tính).
   - **`1.2 Thang đo và phân loại dữ liệu thống kê`**
     - Dãy ID: `PTDLKD_C01_201` $\rightarrow$ `PTDLKD_C01_299`
     - Trọng tâm: 4 loại thang đo (Định danh - Nominal, Thứ bậc - Ordinal, Khoảng - Interval, Tỷ lệ - Ratio); Dữ liệu định tính/định lượng, sơ cấp/thứ cấp.
   - **`1.3 Thu thập và kiểm soát sai số dữ liệu`**
     - Dãy ID: `PTDLKD_C01_301` $\rightarrow$ `PTDLKD_C01_399`
     - Trọng tâm: Điều tra toàn bộ/không toàn bộ, sai số do đăng ký, sai số do tính chất đại biểu.

2. **`C02_PhanToVaThongKeMoTa` — Chương 2: Tóm tắt, phân tổ và thống kê mô tả dữ liệu:**
   - **`2.1 Thu thập, phân tổ và mật độ phân phối`**
     - Dãy ID: `PTDLKD_C02_101` $\rightarrow$ `PTDLKD_C02_199`
     - Trọng tâm: Công thức Sturgess ($k, h$), bảng phân tổ có khoảng cách tổ đều/không đều, mật độ phân phối $d_i = m_i / h_i$.
   - **`2.2 Các đặc trưng đo lường độ tập trung`**
     - Dãy ID: `PTDLKD_C02_201` $\rightarrow$ `PTDLKD_C02_299`
     - Trọng tâm: Số bình quân $\bar{x}$ (giản đơn/gia quyền), mốt $M_o$ (công thức nội suy tổ chứa mốt), trung vị $M_e$.
   - **`2.3 Các đặc trưng đo lường độ phân tán và hình dáng phân phối`**
     - Dãy ID: `PTDLKD_C02_301` $\rightarrow$ `PTDLKD_C02_399`
     - Trọng tâm: Phương sai mẫu hiệu chỉnh $s^2$, độ lệch chuẩn $s$, hệ số biến thiên $CV$, quan hệ $\bar{x}, M_e, M_o$ biện luận phân phối chuẩn/lệch trái/lệch phải.

3. **`C03_ChiSoKinhTe` — Chương 3: Chỉ số kinh tế và phân tích biến động:**
   - **`3.1 Khái niệm, phân loại và chỉ số đơn`**
     - Dãy ID: `PTDLKD_C03_101` $\rightarrow$ `PTDLKD_C03_199`
     - Trọng tâm: Định nghĩa chỉ số, chỉ số phát triển, chỉ số không gian, chỉ số cá thể (đơn) về giá $i_p$ và lượng $i_q$.
   - **`3.2 Chỉ số tổng hợp giá và khối lượng`**
     - Dãy ID: `PTDLKD_C03_201` $\rightarrow$ `PTDLKD_C03_299`
     - Trọng tâm: Chỉ số giá Laspeyres ($I_p^L$), Paasche ($I_p^P$), Fisher ($I_p^F$); Chỉ số khối lượng Laspeyres ($I_q^L$), Paasche ($I_q^P$); Nguyên tắc chọn quyền số kỳ gốc/kỳ báo cáo.
   - **`3.3 Hệ thống chỉ số nhân tố và biến động chi phí`**
     - Dãy ID: `PTDLKD_C03_301` $\rightarrow$ `PTDLKD_C03_399`
     - Trọng tâm: Phương trình cân bằng chỉ số $I_{pq} = I_p \times I_q$; Phân tích biến động chi phí tuyệt đối $\Delta C = \Delta C_p + \Delta C_q$ do giá và khối lượng tiêu thụ.

4. **`C04_DaySoThoiGian` — Chương 4: Phân tích dãy số thời gian và dự báo:**
   - **`4.1 Phân loại dãy số thời gian`**
     - Dãy ID: `PTDLKD_C04_101` $\rightarrow$ `PTDLKD_C04_199`
     - Trọng tâm: Phân biệt dãy số thời kỳ (các mức độ cộng dồn được) và thời điểm (không cộng dồn được).
   - **`4.2 Các chỉ tiêu phân tích dãy số thời gian`**
     - Dãy ID: `PTDLKD_C04_201` $\rightarrow$ `PTDLKD_C04_299`
     - Trọng tâm: Mức độ bình quân theo thời gian ($\bar{y}$), lượng tăng/giảm tuyệt đối (liên hoàn, định gốc, bình quân $\bar{\Delta}$), tốc độ phát triển (liên hoàn, định gốc, bình quân $\bar{t}$), tốc độ tăng giảm ($a$).
   - **`4.3 Các phương pháp dự báo thống kê trong kinh doanh`**
     - Dãy ID: `PTDLKD_C04_301` $\rightarrow$ `PTDLKD_C04_399`
     - Trọng tâm: Dự báo dựa vào lượng tăng giảm tuyệt đối bình quân, tốc độ phát triển bình quân, ngoại suy hàm xu thế, yếu tố thời vụ.

5. **`C05_UocLuongThamSo` — Chương 5: Mẫu ngẫu nhiên và bài toán ước lượng thống kê:**
   - **`5.1 Phân phối chọn mẫu và Định lý giới hạn trung tâm`**
     - Dãy ID: `PTDLKD_C05_101` $\rightarrow$ `PTDLKD_C05_199`
     - Trọng tâm: Mẫu ngẫu nhiên, sai số chọn mẫu chuẩn ($SE = s/\sqrt{n}$), định lý giới hạn trung tâm (CLT).
   - **`5.2 Khoảng tin cậy cho trung bình tổng thể`**
     - Dãy ID: `PTDLKD_C05_201` $\rightarrow$ `PTDLKD_C05_299`
     - Trọng tâm: Ước lượng điểm, ước lượng khoảng đối xứng/1 phía cho $\mu$ khi đã biết $\sigma$ (phân phối chuẩn $z_{\alpha/2}, z_\alpha$) và chưa biết $\sigma$ (mẫu nhỏ dùng $t$-Student $t_{\alpha/2}^{(n-1)}$). Tra bảng UFM bằng tay.
   - **`5.3 Ước lượng tỷ lệ và xác định cỡ mẫu tối thiểu`**
     - Dãy ID: `PTDLKD_C05_301` $\rightarrow$ `PTDLKD_C05_399`
     - Trọng tâm: Khoảng tin cậy cho tỷ lệ tổng thể $p$, công thức cỡ mẫu tối thiểu cho ước lượng trung bình ($n \ge \frac{z_{\alpha/2}^2 \sigma^2}{\epsilon^2}$) và ước lượng tỷ lệ ($n \ge \frac{z_{\alpha/2}^2 p(1-p)}{\epsilon^2}$, làm tròn lên số nguyên kế tiếp).

6. **`C06_KiemDinhGiaThuyet` — Chương 6: Kiểm định giả thuyết thống kê trong kinh doanh:**
   - **`6.1 Nguyên lý kiểm định giả thuyết và sai lầm`**
     - Dãy ID: `PTDLKD_C06_101` $\rightarrow$ `PTDLKD_C06_199`
     - Trọng tâm: Cặp giả thuyết $H_0, H_1$, miền bác bỏ $W_\alpha$, sai lầm loại 1 ($\alpha$) và loại 2 ($\beta$), ý nghĩa xác suất $p$-value.
   - **`6.2 Kiểm định trung bình và kiểm định tỷ lệ một tổng thể`**
     - Dãy ID: `PTDLKD_C06_201` $\rightarrow$ `PTDLKD_C06_299`
     - Trọng tâm: Tính tiêu chuẩn kiểm định $Z_{qs}, t_{qs}$, so sánh với giá trị tới hạn để kết luận bài toán kinh doanh (1 phía hoặc 2 phía). Tra bảng Laplace và Student UFM.
   - **`6.3 So sánh hai tham số và phân tích ANOVA một chiều`**
     - Dãy ID: `PTDLKD_C06_301` $\rightarrow$ `PTDLKD_C06_399`
     - Trọng tâm: Kiểm định so sánh hai trung bình, so sánh hai tỷ lệ, phân tích phương sai ANOVA một chiều ($F$-test), đọc và diễn giải bảng kết quả phần mềm R trong kinh doanh.

---

## 7.1. Kịch Bản Ra Đề Linh Hoạt

Khi người dùng ra lệnh, Skill hỗ trợ 2 kịch bản:
- **Kịch bản A — Tạo theo Chủ đề con cụ thể (Micro-learning):**
  * *Ví dụ:* *"Tạo 5 câu cho mục 2.2 Các đặc trưng đo lường độ tập trung"*.
  * *Thực hiện:* Tạo câu hỏi với trường `"subTopic": "2.2 Các đặc trưng đo lường độ tập trung"` và đánh số ID bắt đầu từ `PTDLKD_C02_201` (dải 201–299).
- **Kịch bản B — Tạo cho toàn bộ Chương:**
  * *Ví dụ:* *"Tạo 15 câu cho Chương 2"*.
  * *Thực hiện:* Tự động chia đều 15 câu vào 3 chủ đề con (mỗi chủ đề con 5 câu: 5 câu dải 101 cho 2.1, 5 câu dải 201 cho 2.2, 5 câu dải 301 cho 2.3), đảm bảo ma trận 60/30/10.

---

## 8. Cơ chế Bắt tay Thông minh (Smart Handshake) với `curriculum-topic-creator`

Trước khi bắt đầu biên soạn câu hỏi cho bất kỳ Chương nào (`C01` đến `C06`), Skill BẮT BUỘC tuân thủ chu trình tiếp ứng 2 bước:

1. **Kiểm tra Tệp Dữ liệu Quarto Gốc (`00_du_lieu_ra_de/*.qmd`):**
   - Quét thư mục `00_du_lieu_ra_de/` tìm tệp tương ứng: `tai_lieu_<MÃ_CHƯƠNG>_*.qmd` (ví dụ: `tai_lieu_C02_PhanToVaThongKeMoTa.qmd`).
   - **Trường hợp A (Đã có tệp `.qmd`):** Đọc nội dung tệp để lấy dữ liệu nền tảng:
     * Trích xuất chính xác danh mục chuyên đề con để gán vào thuộc tính `"subTopic"`.
     * Bám sát các công thức, dạng bài tập điển hình và các bẫy tư duy kinh điển đã được đúc kết trong tệp `.qmd` để thiết kế phương án đúng và phương án nhiễu.
   - **Trường hợp B (Chưa có tệp `.qmd`):** Chủ động thông báo cho Giảng viên:
     > *"Chương `<MÃ_CHƯƠNG>` chưa có tài liệu chuyên đề chuẩn trong `00_du_lieu_ra_de/`. Tôi sẽ kích hoạt skill `curriculum-topic-creator` để khảo sát internet, thiết lập Cây chuyên đề 2 cấp độ và xuất bản tệp `tai_lieu_<MÃ_CHƯƠNG>.qmd` cho Thầy/Cô duyệt trước nhé!"*

2. **Danh mục tài liệu tham chiếu bổ trợ:**
   - [`bang_tra_thong_ke_ufm.md`](references/bang_tra_thong_ke_ufm.md): Bảng tra cứu phân phối xác suất thống kê UFM (Gauss/Laplace, Student, Chi-bình phương, Fisher) kèm quy tắc nội suy lấy trung bình cộng.
   - `00_Course-Map.md`: Tiến trình 15 buổi học, phân bổ đánh giá QT1, QT2 và thi kết thúc học phần.
   - `Đề cương thu gọn có điều chỉnh.md`: Danh mục chi tiết các mục con và bài tập thực hành R của 6 chương.
   - `Đề số 01.docx` / `Đề số 01.pdf`: Đề thi thực tế học phần Phân tích dữ liệu kinh doanh của UFM (chuẩn mực đối sánh).
