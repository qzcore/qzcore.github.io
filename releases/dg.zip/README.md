# Gói không gian làm việc khảo thí môn học (Mẫu chuẩn v5.0.1)

> **Tác giả phát triển phần mềm:** Thầy T.M. Tường & Trợ lý AI Antigravity (Google DeepMind)

Đây là gói thư mục làm việc chuẩn hóa dành cho một môn học trắc nghiệm. Khi chuyển giao cho giảng viên hoặc triển khai môn học mới:

1. **Đổi tên thư mục:** Đổi tên thư mục này thành tên môn học tương ứng (ví dụ: `Toan_kinh_te`, `01_PTDLKD`, `Xac_suat_thong_ke`...).
2. **Tài liệu & Ứng dụng:**
   - **`Mo_App_Mon_Hoc.command` (macOS) / `Mo_App_Mon_Hoc.bat` (Windows):** Nhấp đúp chuột để mở ứng dụng ở chế độ Cửa sổ App PWA độc lập (không thanh địa chỉ, không vướng tab trình duyệt, giao diện chuyên nghiệp như phần mềm độc lập cho môn học).
   - **`Duyet_va_tao_de.html`:** Mở trực tiếp bằng Google Chrome / MS Edge để quản trị môn học, thẩm định đề thô, sinh đề thi và kết nối Cloud.
   - **`HUONG_DAN_SU_DUNG.html` (và `.md`):** Hướng dẫn tổng quan quy trình 4 bước khép kín.
   - **`HUONG_DAN_CAI_DAT_GOOGLE_SHEET.html` (và `.md`):** Hướng dẫn 3 phút cài đặt Google Sheets, dán mã Apps Script và lấy link thi cho sinh viên.
   - **`Cai_Dat_Hoac_Cap_Nhat.bat` / `Cai_Dat_Hoac_Cap_Nhat.sh`:** Bộ kịch bản cập nhật môn học thông minh native (bảo vệ 100% ngân hàng câu hỏi).
3. **Kỹ năng AI Biên soạn Đề chuẩn hóa (`.agents/skills/`):**
   - **`curriculum-topic-creator`:** Khảo sát internet và thiết lập Cây chuyên đề 2 cấp độ dạng Quarto `.qmd` tại `00_du_lieu_ra_de/`.
   - **`exam-creator`:** Biên soạn câu hỏi trắc nghiệm chuẩn hóa 11 tiêu chí (V01 – V11), phân cấp `subTopic` và kèm bảng tra thống kê.
4. **Cấu trúc 7 thư mục chuẩn:**
   - `00_du_lieu_ra_de/`: Đề cương, bài giảng, tài liệu chuyên đề Quarto `.qmd`.
   - `01_ngan_hang_de_tho/`: Ngân hàng câu hỏi thô dạng JSON theo từng chương.
   - `02_ngan_hang_de/`: Ngân hàng câu hỏi chính thức đã thẩm định và duyệt.
   - `03_de_thi/`: Đề thi chính thức dạng snapshot (phục vụ khảo thí trực tuyến hoặc in giấy).
   - `04_de_thuc_hanh/`: Các bộ đề thực hành và bài tập theo tuần (`bai_tap/`) cho sinh viên tự học.
   - `05_xuat_ban_pdf/`: Mẫu in ấn đề thi ra giấy bằng Quarto/PDF.
   - `06_duyet_va_tao_de/`: Bản sao lưu trữ ứng dụng duyệt đề và tạo đề thi offline.

